# RAVEN

RAVEN (Regeneration filter with Adaptive Variational Edge-preserving Neighbourhoods) removes near salt-and-pepper noise. It keeps the mask and the synchronous sweeps of the Regeneration filter and replaces the weighted-average restoration by a joint, mask-constrained total generalized variation (TGV) reconstruction, solved by a first-order primal–dual method.

Manuscript: R. M. Ivković, *RAVEN: A Total Generalized Variation Extension of the Regeneration Filter for Near Salt-and-Pepper Noise*, submitted to Numerical Algorithms.

## Contents

| Path | Purpose |
|---|---|
| `python/core3.py` | Mask (Eq. 2), Regeneration reference by synchronous sweeps until the mask is empty (Eqs. 3–4, Proposition 1), ISII as published, 3 × 3 median and adaptive median filters |
| `python/tgvnb.py` | Primal–dual iteration (7) for model (6), compiled with Numba |
| `python/solvers3.py` | NumPy version of (7) with residuals and objective values, first-order TV variant, ADMM solver of (6) |
| `python/amf_fast.py`, `python/dba.py` | Adaptive median filter (levels A and B, largest window 39 × 39) and DBA for the controlled comparison |
| `python/ravenlib.py` | PSNR, SSIM with MATLAB defaults, MATLAB-compatible Canny edges and imhist, DCT level-of-detail class |
| `python/run_v3.py` | Main study: Kodak24 (nS&P, 13 densities) and CBSD68 (salt and pepper, 10 densities, with median, AMF and DBA), three realizations |
| `python/run_ablation3.py` | Ablation (Table 6) |
| `python/run_conv3.py` | Convergence study and ADMM comparison (Fig. 8) |
| `python/tune3.py` | Parameter check on McMaster (Section 3.3) |
| `python/verify_sweeps.py` | Check of Proposition 1 on every recorded run |
| `python/check_degenerate.py` | Check of Remark 1 (λ0 or λ1 close to zero returns the Regeneration reference) |
| `python/analyze3.py` | Statistics (bootstrap intervals, Wilcoxon tests, Holm adjustment) and Figs. 4–6 and 8 |
| `python/fig7.py` | Fig. 7 |
| `python/run_cbsd68.py`, `python/run_ablation.py`, `python/ablation.py` | Earlier decoupled per-sample variant and the weighted-average filter (Section 5.1) |
| `results/results_v3.jsonl` | PSNR, SSIM, ISII and its three terms for every method, image, density and realization, with seeds, mask fractions, sweep counts and run times |
| `results/results_ablation3.jsonl`, `results/results_conv3.jsonl`, `results/results_tune3.jsonl` | Ablation, convergence and parameter-check records |
| `results/nums3.json` | Aggregated values used in the manuscript |
| `results/verify_sweeps.json`, `results/degenerate_check.json` | Results of `verify_sweeps.py` and `check_degenerate.py` |
| `results/earlier_variant/` | Records of the earlier variant discussed in Section 5.1 |
| `data_checksums/` | SHA-256 checksums of the Kodak24, McMaster and CBSD68 images |
| `matlab/raven_filter.m`, `matlab/RAVEN_demo.m` | MATLAB implementation of the same equations and an example |
| `matlab/isii_index.m`, `matlab/lod_dct_class.m` | ISII (logic of github.com/RatkoIV/ISII, commit 50aad7b) and level-of-detail class |

## Parameters (selected on McMaster, fixed for all tests)

| Parameter | Value |
|---|---|
| Detection bands | [0, 8] and [247, 255] for nS&P, values < 2 or > 254 for salt and pepper |
| Sweeps | until the working mask is empty |
| α, λ0, λ1 (intensities in [0, 1]) | 0.1, 1, 0.5 |
| Step sizes | τ = σ = 0.24 (τσ < 1/16) |
| Primal–dual iterations | 200 |

## Data

* Kodak24 and McMaster: test sets of FFDNet, https://github.com/cszn/FFDNet (commit e787f46), folders `testsets/Kodak24` and `testsets/McMaster`, used as distributed (Kodak24 in 500 × 500 pixels).
* CBSD68: https://github.com/clausmichele/CBSD68-dataset (commit 51a07a9), folder `CBSD68/original_png`.

Point the environment variables `KODAK24`, `CBSD68` and `MCMASTER` to these folders, or place them in `data/Kodak24`, `data/CBSD68` and `data/McMaster` next to `python/`. The checksums in `data_checksums/` identify the files.

## Running

The scripts write and read their records in `python/`. To repeat only the analysis with the records used in the manuscript, copy them there first (`cp ../results/*.jsonl ../results/*.json .` from `python/`).

```
cd python
pip install -r requirements.txt
python run_v3.py          # main study, resumable
python run_ablation3.py
python run_conv3.py
python tune3.py
python verify_sweeps.py
python check_degenerate.py
python analyze3.py        # nums3.json and figures in python/figures
python fig7.py 22 120 160 220
```

## Software

Python 3.13.18, NumPy 2.5.3, SciPy 1.18.1, Numba 0.68.1, Pillow 12.3.0, Matplotlib 3.11.2. The MATLAB files need R2019a or later and the Image Processing Toolbox.

## License

MIT, see `LICENSE`.
