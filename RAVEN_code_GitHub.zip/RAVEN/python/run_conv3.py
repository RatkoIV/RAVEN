"""Convergence study: primal-dual iteration (7) and ADMM on central 256 x 256 crops of six Kodak24 images,
nS&P noise at 10, 50 and 90 percent, realization 0."""
import sys, os, json, time, numpy as np
from multiprocessing import Pool
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import core3 as C, ravenlib as R
from solvers3 import pd_solve, admm_solve
from run_v3 import SETS, corrupt, seed, P

IMGS = [1, 4, 9, 14, 18, 22]
DEN = [10, 50, 90]
ps = lambda I, Z: R.psnr(I, np.floor(np.clip(Z, 0, 255) + 0.5).astype(np.uint8))
ss = lambda I, Z: float(np.mean([R.ssim_matlab(Z[:, :, c], I[:, :, c]) for c in range(3)]))

def job(a):
    k, d = a
    files, dens, kind, T1, T2, sid = SETS['kodak24']
    I0 = np.array(Image.open(files[k]).convert('RGB'))
    di = dens.index(d)
    Y0 = corrupt(I0, d / 100, kind, seed(sid, k, di, 0))
    c0 = (I0.shape[0] - 256) // 2; c1 = (I0.shape[1] - 256) // 2
    I = I0[c0:c0 + 256, c1:c1 + 256]; Y = Y0[c0:c0 + 256, c1:c1 + 256].astype(np.float64)
    M = (Y <= T1) | (Y >= T2)
    Rf, _ = C.reference(Y, M)
    X, D, _ = pd_solve(Y, M, Rf, P['alpha'], P['lam0'], P['lam1'], 1000, True, False, P['step'], track=True, I=I, every=10,
                       ssim_fn=ss, psnr_fn=ps)
    Xa, Da = admm_solve(Y, M, Rf, P['alpha'], P['lam0'], P['lam1'], iters=300, cg_iters=15)
    return dict(k=k, density=d, file=os.path.basename(files[k]), pd=D, admm=Da, psnr_ref=ps(I, Rf), ssim_ref=ss(I, Rf),
                psnr_admm=ps(I, Xa), ssim_admm=ss(I, Xa))

if __name__ == '__main__':
    OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_conv3.jsonl')
    tasks = [(k, d) for k in IMGS for d in DEN]
    t0 = time.time()
    with Pool(2) as pool, open(OUT, 'w') as f:
        for i, x in enumerate(pool.imap_unordered(job, tasks, chunksize=1)):
            f.write(json.dumps(x) + '\n'); f.flush(); print(i, round(time.time() - t0), flush=True)
    print('done', time.time() - t0)
