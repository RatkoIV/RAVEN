"""Decision-based algorithm (DBA) of Srinivasan and Ebenezer (2007), per channel, raster order, in place."""
import numpy as np
from numba import njit

@njit(cache=True)
def _dba(X):
    h, w = X.shape
    Y = X.copy()
    win = np.zeros(9)
    for i in range(h):
        for j in range(w):
            v = Y[i, j]
            if v > 0 and v < 255:
                continue
            n = 0
            for di in range(-1, 2):
                for dj in range(-1, 2):
                    p = min(max(i + di, 0), h - 1)
                    q = min(max(j + dj, 0), w - 1)
                    win[n] = Y[p, q]; n += 1
            med = np.sort(win)[4]
            if med > 0 and med < 255:
                Y[i, j] = med
            else:
                if j > 0:
                    Y[i, j] = Y[i, j - 1]
                elif i > 0:
                    Y[i, j] = Y[i - 1, j]
    return Y

def dba(Y):
    Y = np.asarray(Y, np.float64)
    return np.stack([_dba(np.ascontiguousarray(Y[:, :, c])) for c in range(Y.shape[2])], 2)
