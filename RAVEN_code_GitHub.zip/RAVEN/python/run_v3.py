"""Main study of the revision: three noise realizations, sweeps until the mask is empty, public ISII,
controlled baselines on CBSD68."""
import sys, json, os, time, glob, numpy as np
from multiprocessing import Pool
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import core3 as C
from tgvnb import tgv_solve_nb
from dba import dba
import amf_fast

P = dict(alpha=0.1, lam0=1.0, lam1=0.5, iters=200, step=0.24)
CBSD = os.environ.get('CBSD68', os.path.join(HERE, '..', 'data', 'CBSD68'))
KOD = os.environ.get('KODAK24', os.path.join(HERE, '..', 'data', 'Kodak24'))
SETS = {'kodak24': (sorted(glob.glob(KOD + '/*.png')), [1, 2, 3, 4, 5, 7.5, 10, 30, 40, 50, 70, 80, 90], 'nsp', 8, 247, 2),
        'cbsd68': (sorted(glob.glob(CBSD + '/*.png')), [10, 20, 30, 40, 50, 60, 70, 80, 90, 95], 'sp', 1, 255, 1)}
NREAL = 3

def corrupt(I, p, kind, seed):
    rng = np.random.default_rng(seed)
    b = rng.random(I.shape); Y = I.copy()
    lo = b < p / 2; hi = (b >= p / 2) & (b < p)
    if kind == 'sp':
        Y[lo] = 0; Y[hi] = 255
    else:
        Y[lo] = rng.integers(0, 9, lo.sum()); Y[hi] = rng.integers(247, 256, hi.sum())
    return Y

def seed(sid, k, di, r):
    return 100000 * sid + 1000 * (k + 1) + di + 7919 * r

q = lambda Z: np.floor(np.clip(Z, 0, 255) + 0.5).astype(np.uint8)

def job(a):
    s, k, di, r = a
    files, dens, kind, T1, T2, sid = SETS[s]
    I = np.array(Image.open(files[k]).convert('RGB'))
    Y = corrupt(I, dens[di] / 100, kind, seed(sid, k, di, r)).astype(np.float64)
    M = (Y <= T1) | (Y >= T2)
    t = time.time(); Rf, sw = C.reference(Y, M); tr = time.time() - t
    t = time.time(); X = tgv_solve_nb(Y, M, Rf, P['alpha'], P['lam0'], P['lam1'], P['iters'], True, P['step']); tt = time.time() - t
    rec = dict(set=s, img=os.path.basename(files[k]), k=k, density=dens[di], r=r, seed=seed(sid, k, di, r),
               mask=float(M.mean()), false_mask=float(np.mean(M & (Y == I))), sweeps=sw, t_ref=tr, t_tgv=tt,
               reg=C.metrics(I, q(Rf)), rav=C.metrics(I, q(X)))
    if s == 'kodak24' and r == 0:
        M2 = (Y <= 1) | (Y >= 255)
        rec['reg_own'] = C.metrics(I, q(C.reference(Y, M2)[0]))
    if s == 'cbsd68':
        rec['mf'] = C.metrics(I, q(C.median3(Y)))
        t = time.time(); rec['amf'] = C.metrics(I, q(amf_fast.amf(Y))); rec['t_amf'] = time.time() - t
        rec['dba'] = C.metrics(I, q(dba(Y)))
    return rec

if __name__ == '__main__':
    OUT = os.environ.get('OUT', os.path.join(HERE, 'results_v3.jsonl'))
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT):
            x = json.loads(l); done.add((x['set'], x['k'], x['density'], x['r']))
    tasks = [(s, k, di, r) for r in range(NREAL) for s in ('kodak24', 'cbsd68') for k in range(len(SETS[s][0]))
             for di in range(len(SETS[s][1])) if (s, k, SETS[s][1][di], r) not in done]
    Z = np.zeros((8, 8, 3)); Mz = np.zeros((8, 8, 3), bool); Mz[2, 2] = True
    tgv_solve_nb(Z, Mz, Z, 0.1, 1, 0.5, 2, True, 0.24); C.reference(Z, Mz); amf_fast.amf(Z); dba(Z)
    t0 = time.time()
    with Pool(2) as pool, open(OUT, 'a') as f:
        for i, x in enumerate(pool.imap_unordered(job, tasks, chunksize=1)):
            f.write(json.dumps(x) + '\n'); f.flush()
            if i % 50 == 0:
                print(i, len(tasks), round(time.time() - t0), flush=True)
    print('done', time.time() - t0)
