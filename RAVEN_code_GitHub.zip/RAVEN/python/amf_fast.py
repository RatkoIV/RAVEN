"""Adaptive median filter with incremental window histograms (identical output to core3.amf for 8-bit data)."""
import numpy as np
from numba import njit


@njit(cache=True)
def _kth(hist, kk):
    s = 0
    for v in range(256):
        s += hist[v]
        if s > kk:
            return v
    return 255


@njit(cache=True)
def _amf_fast(X, smax):
    h, w = X.shape
    Xi = np.empty((h, w), np.int64)
    for i in range(h):
        for j in range(w):
            Xi[i, j] = int(X[i, j])
    out = X.copy()
    hist = np.zeros(256, np.int64)
    for i in range(h):
        for j in range(w):
            z = X[i, j]
            hist[:] = 0
            n = 0
            # 3 x 3 window
            i0 = max(0, i - 1); i1 = min(h - 1, i + 1); j0 = max(0, j - 1); j1 = min(w - 1, j + 1)
            for p in range(i0, i1 + 1):
                for q in range(j0, j1 + 1):
                    hist[Xi[p, q]] += 1; n += 1
            s = 1
            while True:
                zmin = 0
                while hist[zmin] == 0:
                    zmin += 1
                zmax = 255
                while hist[zmax] == 0:
                    zmax -= 1
                if n % 2 == 1:
                    zmed = float(_kth(hist, n // 2))
                else:
                    zmed = 0.5 * (_kth(hist, n // 2 - 1) + _kth(hist, n // 2))
                if zmin < zmed < zmax:
                    out[i, j] = z if (zmin < z < zmax) else zmed
                    break
                s += 1
                if 2 * s + 1 > smax:
                    out[i, j] = zmed
                    break
                # grow window from s-1 to s: add the new ring inside the image
                ni0 = max(0, i - s); ni1 = min(h - 1, i + s); nj0 = max(0, j - s); nj1 = min(w - 1, j + s)
                for p in range(ni0, ni1 + 1):
                    for q in range(nj0, nj1 + 1):
                        if p < i0 or p > i1 or q < j0 or q > j1:
                            hist[Xi[p, q]] += 1; n += 1
                i0, i1, j0, j1 = ni0, ni1, nj0, nj1
    return out


def amf(Y, smax=39):
    Y = np.asarray(Y, np.float64)
    return np.stack([_amf_fast(np.ascontiguousarray(Y[:, :, c]), smax) for c in range(Y.shape[2])], 2)
