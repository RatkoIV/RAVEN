"""Ablation variants sharing RAVEN's sweep machinery.
A: Regeneration in the weighted-average form of [5] (Eqs. 3-4 of the manuscript): detection <2 or >254, Gaussian spatial weights, x = R.
B: RAVEN without the variational step: detection [0,8]U[247,255], weights of Eq. (4), x = R."""
import numpy as np
from numba import njit
import ravenlib as R

@njit(cache=True)
def _nb3_plain(Xc, M, i, j, h, w, vals, wts):
    n = 0
    for di in range(-1, 2):
        for dj in range(-1, 2):
            if di == 0 and dj == 0:
                continue
            p = i + di; q = j + dj
            if p >= 0 and p < h and q >= 0 and q < w and not M[p, q]:
                vals[n] = Xc[p, q]; wts[n] = np.exp(-(di * di + dj * dj) / 2.0); n += 1
    return n

@njit(cache=True)
def _avg_channel(Xc, T1, T2, T_outer, dirs, photometric):
    h, w = Xc.shape
    Xc = Xc.copy()
    M = (Xc <= T1) | (Xc >= T2)
    vals = np.zeros(24); wts = np.zeros(24)
    for t in range(T_outer):
        for d in range(dirs.shape[0]):
            if not M.any():
                break
            newX = Xc.copy(); newM = M.copy()
            for i in range(h):
                for j in range(w):
                    if not M[i, j]:
                        continue
                    if photometric:
                        n = R._nb3(Xc, M, i, j, h, w, vals, wts)
                    else:
                        n = _nb3_plain(Xc, M, i, j, h, w, vals, wts)
                    if n == 0:
                        n = R._nb5(Xc, M, i, j, h, w, vals, wts)
                        if n == 0:
                            continue
                    s = 0.0; sw = 0.0
                    for k in range(n):
                        s += wts[k] * vals[k]; sw += wts[k]
                    newX[i, j] = s / sw
                    newM[i, j] = False
            Xc = newX; M = newM
        if not M.any():
            break
    return Xc

def variant(Y, which):
    Y = np.asarray(Y, np.float64)
    if which == 'A':
        T1, T2, ph = 1, 255, False
    else:
        T1, T2, ph = 8, 247, True
    return np.stack([_avg_channel(np.ascontiguousarray(Y[:, :, c]), T1, T2, 4, R.DIRS, ph)
                     for c in range(Y.shape[2])], 2)
