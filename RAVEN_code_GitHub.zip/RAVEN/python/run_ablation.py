import sys, json, os, time, numpy as np
from multiprocessing import Pool
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ravenlib as R
from ablation import variant
from run_cbsd68 import noisy, FILES, DENS, metrics
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_ablation.jsonl')
def job(a):
    k, d = a
    I = np.array(Image.open(FILES[k]).convert('RGB'))
    Y = noisy(I, DENS[d] / 100.0, 1000 * (k + 1) + d)
    rec = dict(img=os.path.basename(FILES[k]), k=k, density=DENS[d])
    for v in ('A', 'B'):
        Z = np.floor(variant(Y, v) + 0.5).astype(np.uint8)
        rec[v] = metrics(I, Z)
    return rec
if __name__ == '__main__':
    variant(np.zeros((6, 6, 1)), 'A'); variant(np.zeros((6, 6, 1)), 'B')
    tasks = [(k, d) for k in range(len(FILES)) for d in range(len(DENS))]
    t0 = time.time()
    with Pool(2) as p, open(OUT, 'w') as f:
        for i, r in enumerate(p.imap_unordered(job, tasks, chunksize=2)):
            f.write(json.dumps(r) + '\n'); f.flush()
            if i % 100 == 0: print(i, time.time() - t0, flush=True)
    print('done', time.time() - t0)
