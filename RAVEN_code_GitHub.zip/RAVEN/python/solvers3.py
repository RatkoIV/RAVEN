"""Primal-dual and ADMM solvers of model (6) with convergence diagnostics (intensities scaled to [0,1])."""
import time
import numpy as np


# forward differences with a zero difference at the last column (x) or row (y)
def fx(u):
    d = np.zeros_like(u); d[:, :-1] = u[:, 1:] - u[:, :-1]; return d


def fy(u):
    d = np.zeros_like(u); d[:-1] = u[1:] - u[:-1]; return d


# backward differences, the negative adjoints of fx and fy
def bx(p):
    d = np.zeros_like(p); d[:, 0] = p[:, 0]; d[:, 1:-1] = p[:, 1:-1] - p[:, :-2]; d[:, -1] = -p[:, -2]; return d


def by(p):
    d = np.zeros_like(p); d[0] = p[0]; d[1:-1] = p[1:-1] - p[:-2]; d[-1] = -p[-2]; return d


def grad(X):
    return fx(X), fy(X)


def div(p1, p2):
    return bx(p1) + by(p2)


def Eop(v1, v2):
    return bx(v1), by(v2), 0.5 * (by(v1) + bx(v2))


def div2(q11, q22, q12):
    return fx(q11) + fy(q12), fx(q12) + fy(q22)


def pnorm(a, b, vec):
    n = a ** 2 + b ** 2
    return np.sqrt(n.sum(2, keepdims=True)) if vec else np.sqrt(n)


def qnorm(a, b, c, vec):
    n = a ** 2 + b ** 2 + 2 * c ** 2
    return np.sqrt(n.sum(2, keepdims=True)) if vec else np.sqrt(n)


def objective(X, v1, v2, R, M, alpha, lam0, lam1, vec=True, tv_only=False):
    g1, g2 = grad(X)
    if tv_only:
        v1 = np.zeros_like(X); v2 = np.zeros_like(X)
    f = 0.5 * alpha * np.sum((X - R)[M] ** 2)
    f += lam0 * np.sum(pnorm(g1 - v1, g2 - v2, vec))
    if not tv_only:
        e11, e22, e12 = Eop(v1, v2)
        f += lam1 * np.sum(qnorm(e11, e22, e12, vec))
    return float(f)


def pd_solve(Y, M, Rf, alpha=0.1, lam0=1.0, lam1=0.5, iters=200, vec=True, tv_only=False, step=0.24,
             track=False, I=None, every=1, ssim_fn=None, psnr_fn=None):
    """Iteration (7). tv_only fixes v = 0 (first-order TV). Returns X (0..255) and a diagnostics dict."""
    Y = np.asarray(Y, np.float64) / 255.0; R = np.asarray(Rf, np.float64) / 255.0
    A = ~M
    X = R.copy(); X[A] = Y[A]
    v1, v2 = (np.zeros_like(X), np.zeros_like(X)) if tv_only else grad(X)
    p1 = np.zeros_like(X); p2 = np.zeros_like(X)
    q11 = np.zeros_like(X); q22 = np.zeros_like(X); q12 = np.zeros_like(X)
    Xb, v1b, v2b = X.copy(), v1.copy(), v2.copy()
    tau = sig = step
    D = dict(it=[], obj=[], rel=[], pres=[], dres=[], t=[], psnr=[], ssim=[])
    t0 = time.time(); t_track = 0.0
    for k in range(1, iters + 1):
        p1o, p2o, q11o, q22o, q12o = p1.copy(), p2.copy(), q11.copy(), q22.copy(), q12.copy()
        Xbu, v1bu, v2bu = Xb, v1b, v2b
        g1, g2 = grad(Xb)
        p1 = p1 + sig * (g1 - v1b); p2 = p2 + sig * (g2 - v2b)
        s = np.maximum(1.0, pnorm(p1, p2, vec) / lam0); p1 /= s; p2 /= s
        if not tv_only:
            e11, e22, e12 = Eop(v1b, v2b)
            q11 = q11 + sig * e11; q22 = q22 + sig * e22; q12 = q12 + sig * e12
            s = np.maximum(1.0, qnorm(q11, q22, q12, vec) / lam1); q11 /= s; q22 /= s; q12 /= s
        Xo, v1o, v2o = X, v1, v2
        Xt = X + tau * div(p1, p2)
        X = np.where(A, Y, np.clip((Xt + tau * alpha * R) / (1 + tau * alpha), 0, 1))
        if not tv_only:
            d1, d2 = div2(q11, q22, q12)
            v1 = v1 + tau * (p1 + d1); v2 = v2 + tau * (p2 + d2)
        Xb = 2 * X - Xo; v1b = 2 * v1 - v1o; v2b = 2 * v2 - v2o
        if track and (k % every == 0 or k == 1):
            ts = time.time()
            # residuals of the optimality conditions of the saddle-point problem for the order of (7):
            # primal  (x^{k-1} - x^k)/tau  lies in dG(x^k) + K^T y^k,
            # dual    (y^{k-1} - y^k)/sigma + K(xbar^{k-1} - x^k)  lies in dF*(y^k) - K x^k.
            pr = np.sqrt(np.sum(((Xo - X) / tau) ** 2) + np.sum(((v1o - v1) / tau) ** 2 + ((v2o - v2) / tau) ** 2))
            eX, e1, e2 = Xbu - X, v1bu - v1, v2bu - v2
            gx, gy = grad(eX)
            dr2 = np.sum(((p1o - p1) / sig + gx - e1) ** 2 + ((p2o - p2) / sig + gy - e2) ** 2)
            if not tv_only:
                f11, f22, f12 = Eop(e1, e2)
                dr2 += np.sum(((q11o - q11) / sig + f11) ** 2 + ((q22o - q22) / sig + f22) ** 2 + 2 * ((q12o - q12) / sig + f12) ** 2)
            obj = objective(X, v1, v2, R, M, alpha, lam0, lam1, vec, tv_only)
            rel = float(np.linalg.norm(Xo - X) / max(np.linalg.norm(X), 1e-12))
            if I is not None:
                Z = np.floor(np.clip(X * 255, 0, 255) + 0.5).astype(np.uint8)
                D['psnr'].append(psnr_fn(I, Z)); D['ssim'].append(ssim_fn(I, Z))
            t_track += time.time() - ts
            D['it'].append(k); D['t'].append(time.time() - t0 - t_track)
            D['obj'].append(obj); D['rel'].append(rel)
            D['pres'].append(float(pr)); D['dres'].append(float(np.sqrt(dr2)))
    D['time'] = time.time() - t0 - t_track
    return X * 255.0, D, (v1, v2)


# ------------------------------------------------------------------ ADMM with residual balancing
def admm_solve(Y, M, Rf, alpha=0.1, lam0=1.0, lam1=0.5, iters=100, rho=1.0, cg_iters=10, vec=True,
               mu=10.0, tauf=2.0, track=True):
    """Scaled ADMM for (6) with z1 = grad X - v, z2 = E v, w = X (box); the (X_M, v) subproblem is a
    symmetric positive definite system solved by warm-started conjugate gradients; the penalty is
    adapted by residual balancing with mu = 10 and tau = 2 [23]."""
    Y = np.asarray(Y, np.float64) / 255.0; R = np.asarray(Rf, np.float64) / 255.0
    A = ~M; Mf = M.astype(np.float64)
    xA = np.where(A, Y, 0.0)
    xM = np.where(M, R, 0.0)
    X = xA + xM
    v1, v2 = grad(X)
    z1a, z1b = grad(X)[0] - v1, grad(X)[1] - v2
    z2a, z2b, z2c = Eop(v1, v2)
    w = X.copy()
    u1a = np.zeros_like(X); u1b = np.zeros_like(X); u2a = np.zeros_like(X); u2b = np.zeros_like(X); u2c = np.zeros_like(X)
    u3 = np.zeros_like(X)
    gA1, gA2 = grad(xA)
    D = dict(it=[], obj=[], t=[], rho=[], r=[], s=[])
    t0 = time.time(); t_track = 0.0

    def Aop(xm, a1, a2, rho):
        g1, g2 = grad(xm)
        r1, r2 = g1 - a1, g2 - a2
        ox = (alpha + rho) * xm - rho * div(r1, r2)
        ox *= Mf
        e11, e22, e12 = Eop(a1, a2)
        d1, d2 = div2(e11, e22, e12)
        # v equation: -rho grad x + rho v + rho E^T E v, with E^T = -div2
        oa1 = -rho * g1 + rho * a1 - rho * d1
        oa2 = -rho * g2 + rho * a2 - rho * d2
        return ox, oa1, oa2

    def dot(a, b):
        return sum(np.sum(x * y) for x, y in zip(a, b))

    for k in range(1, iters + 1):
        c1a, c1b = z1a - u1a, z1b - u1b
        c2a, c2b, c2c = z2a - u2a, z2b - u2b, z2c - u2c
        c3 = w - u3
        bx_ = (alpha * R + rho * c3 - rho * div(c1a - gA1, c1b - gA2)) * Mf
        d1, d2 = div2(c2a, c2b, c2c)
        bv1 = rho * (gA1 - c1a) - rho * d1
        bv2 = rho * (gA2 - c1b) - rho * d2
        b = (bx_, bv1, bv2)
        xk = (xM, v1, v2)
        Ax = Aop(xM, v1, v2, rho)
        rr = tuple(bi - ai for bi, ai in zip(b, Ax)); pp = rr; rs = dot(rr, rr)
        for _ in range(cg_iters):
            Ap = Aop(*pp, rho)
            al = rs / max(dot(pp, Ap), 1e-30)
            xk = tuple(x + al * p for x, p in zip(xk, pp))
            rr = tuple(r - al * a for r, a in zip(rr, Ap))
            rn = dot(rr, rr)
            if rn < 1e-20:
                break
            pp = tuple(r + (rn / rs) * p for r, p in zip(rr, pp)); rs = rn
        xM, v1, v2 = xk
        X = xA + xM
        g1, g2 = grad(X)
        z1ao, z1bo, z2ao, z2bo, z2co, wo = z1a, z1b, z2a, z2b, z2c, w
        a1, a2 = g1 - v1 + u1a, g2 - v2 + u1b
        s = np.maximum(0, 1 - (lam0 / rho) / np.maximum(pnorm(a1, a2, vec), 1e-12)); z1a, z1b = s * a1, s * a2
        e11, e22, e12 = Eop(v1, v2)
        b1, b2, b3 = e11 + u2a, e22 + u2b, e12 + u2c
        s = np.maximum(0, 1 - (lam1 / rho) / np.maximum(qnorm(b1, b2, b3, vec), 1e-12)); z2a, z2b, z2c = s * b1, s * b2, s * b3
        w = np.where(A, Y, np.clip(X + u3, 0, 1))
        r1a, r1b = g1 - v1 - z1a, g2 - v2 - z1b
        r2a, r2b, r2c = e11 - z2a, e22 - z2b, e12 - z2c
        r3 = X - w
        u1a += r1a; u1b += r1b; u2a += r2a; u2b += r2b; u2c += r2c; u3 += r3
        rnorm = np.sqrt(np.sum(r1a ** 2 + r1b ** 2) + np.sum(r2a ** 2 + r2b ** 2 + 2 * r2c ** 2) + np.sum(r3 ** 2))
        dz1a, dz1b = z1a - z1ao, z1b - z1bo
        dz2a, dz2b, dz2c = z2a - z2ao, z2b - z2bo, z2c - z2co
        dw = w - wo
        sx = -div(dz1a, dz1b) + dw
        a1_, a2_ = div2(dz2a, dz2b, dz2c)
        snorm = rho * np.sqrt(np.sum((sx * Mf) ** 2) + np.sum((-dz1a - a1_) ** 2 + (-dz1b - a2_) ** 2))
        if track:
            ts = time.time()
            Xc = np.where(A, Y, np.clip(X, 0, 1))
            obj = objective(Xc, v1, v2, R, M, alpha, lam0, lam1, vec)
            t_track += time.time() - ts
            D['it'].append(k); D['t'].append(time.time() - t0 - t_track); D['rho'].append(rho)
            D['obj'].append(obj); D['r'].append(float(rnorm)); D['s'].append(float(snorm))
        if rnorm > mu * snorm:
            rho *= tauf; u1a /= tauf; u1b /= tauf; u2a /= tauf; u2b /= tauf; u2c /= tauf; u3 /= tauf
        elif snorm > mu * rnorm:
            rho /= tauf; u1a *= tauf; u1b *= tauf; u2a *= tauf; u2b *= tauf; u2c *= tauf; u3 *= tauf
    D['time'] = time.time() - t0 - t_track
    return np.where(A, Y, np.clip(X, 0, 1)) * 255.0, D
