"""Earlier decoupled per-sample variant (Section 5.1 of the manuscript) and the Regeneration filter on CBSD68, one realization."""
import sys, json, time, glob, os
import numpy as np
from multiprocessing import Pool
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ravenlib as R

DATA = os.environ.get('CBSD68', os.path.join(HERE, '..', 'data', 'CBSD68'))
OUT = os.path.join(HERE, 'results_cbsd68.jsonl')
DENS = [1, 2, 3, 4, 5, 7.5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95]
FILES = sorted(glob.glob(os.path.join(DATA, '*.png')))


def noisy(I, p, seed):
    """MATLAB imnoise(I,'salt & pepper',p): independent per element."""
    rng = np.random.default_rng(seed)
    b = rng.random(I.shape)
    Y = I.copy()
    Y[b < p / 2] = 0
    Y[(b >= p / 2) & (b < p)] = 255
    return Y


def metrics(I, Z):
    gI, gZ = R.rgb2gray(I), R.rgb2gray(Z)
    v = R.isii(I, Z)
    return dict(psnr=R.psnr(I, Z),
                ssim=float(np.mean([R.ssim_matlab(Z[:, :, c], I[:, :, c]) for c in range(3)])),
                psnr_gray=R.psnr(gI, gZ), ssim_gray=R.ssim_matlab(gZ, gI),
                ssim_global_gray=R.ssim_global(gI, gZ),
                isii=v[0], isii_s=v[1], isii_c=v[2], isii_t=v[3])


def job(args):
    k, d = args
    I = np.array(Image.open(FILES[k]).convert('RGB'))
    p = DENS[d] / 100.0
    Y = noisy(I, p, 1000 * (k + 1) + d)
    t = time.time()
    G = R.regeneration_filter(Y).astype(np.uint8)
    tg = time.time() - t
    t = time.time()
    X, sw = R.raven_filter(Y)
    tr = time.time() - t
    Xu = np.floor(X + 0.5).astype(np.uint8)
    rec = dict(img=os.path.basename(FILES[k]), k=k, density=DENS[d], actual=float(np.mean(Y != I)),
               t_reg=tg, t_rav=tr, sweeps=sw,
               reg=metrics(I, G), rav=metrics(I, Xu), noisy=dict(psnr=R.psnr(I, Y)))
    return rec


if __name__ == '__main__':
    done = set()
    if os.path.exists(OUT):
        for line in open(OUT):
            r = json.loads(line); done.add((r['k'], r['density']))
    tasks = [(k, d) for k in range(len(FILES)) for d in range(len(DENS)) if (k, DENS[d]) not in done]
    # warm up numba in the parent cache
    R.raven_filter(np.zeros((8, 8, 1)))
    t0 = time.time()
    with Pool(2) as pool, open(OUT, 'a') as f:
        for i, rec in enumerate(pool.imap_unordered(job, tasks, chunksize=2)):
            f.write(json.dumps(rec) + '\n'); f.flush()
            if i % 50 == 0:
                print(f'{i+1}/{len(tasks)}  {time.time()-t0:.0f}s', flush=True)
    print('done', time.time() - t0)
