"""Parameter check on McMaster (not part of the test sets).

One parameter is varied at a time around alpha = 0.1, lambda1/lambda0 = 0.5, 200 iterations,
under salt-and-pepper noise at 10, 50 and 90 percent. Records go to results_tune3.jsonl.
"""
import os, sys, glob, json, time
import numpy as np
from multiprocessing import Pool
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ravenlib as R
import core3 as C3
from tgvnb import tgv_solve_nb
from run_v3 import corrupt

MCM = os.environ.get('MCMASTER', os.path.join(HERE, '..', 'data', 'McMaster'))
FILES = sorted(glob.glob(os.path.join(MCM, '*.png')) + glob.glob(os.path.join(MCM, '*.tif')))
OUT = os.path.join(HERE, 'results_tune3.jsonl')
DENS = (10, 50, 90)
BASE = dict(alpha=0.1, ratio=0.5, iters=200, vec=True)
CFGS = {'base': BASE}
for r in (0.1, 0.25, 1, 2, 4):
    CFGS[f'ratio{r:g}'] = BASE | {'ratio': r}
for a in (0, 0.3, 1, 3):
    CFGS[f'alpha{a:g}'] = BASE | {'alpha': a}
for it in (100, 300, 400):
    CFGS[f'iters{it}'] = BASE | {'iters': it}
CFGS['chan'] = BASE | {'vec': False}


def q(Z):
    return np.floor(np.clip(Z, 0, 255) + 0.5).astype(np.uint8)


def ev(I, Z):
    Zu = q(Z)
    return R.psnr(I, Zu), float(np.mean([R.ssim_matlab(Zu[:, :, c], I[:, :, c]) for c in range(3)]))


def job(a):
    k, d = a
    I = np.array(Image.open(FILES[k]).convert('RGB'))
    Y = corrupt(I, d / 100, 'sp', 900000 + 1000 * (k + 1) + d).astype(np.float64)
    M = (Y < 2) | (Y > 254)
    Rf, _ = C3.reference(Y, M)
    out = []
    ps, ss = ev(I, Rf)
    out.append(dict(img=k, d=d, cfg='regen', psnr=ps, ssim=ss))
    for name, c in CFGS.items():
        X = tgv_solve_nb(Y, M, Rf, c['alpha'], 1.0, c['ratio'], c['iters'], c['vec'], 0.24)
        ps, ss = ev(I, X)
        out.append(dict(img=k, d=d, cfg=name, psnr=ps, ssim=ss))
    return out


if __name__ == '__main__':
    imgs = [int(x) for x in sys.argv[1].split(',')] if len(sys.argv) > 1 else list(range(0, len(FILES), 3))
    jobs = [(k, d) for k in imgs for d in DENS]
    t0 = time.time()
    with Pool(2) as pool, open(OUT, 'w') as fo:
        for i, rec in enumerate(pool.imap_unordered(job, jobs)):
            for r in rec:
                fo.write(json.dumps(r) + '\n')
            fo.flush()
            print(i + 1, len(jobs), round(time.time() - t0), flush=True)
