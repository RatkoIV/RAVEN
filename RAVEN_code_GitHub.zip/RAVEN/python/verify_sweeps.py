"""Check of Proposition 1 on every recorded run: the number of sweeps of each channel equals
ceil(max d / 2), d the Chebyshev distance to the nearest reliable sample, and no channel is without
reliable samples. Writes verify_sweeps.json."""
import os, sys, json
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_cdt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from run_v3 import SETS, corrupt, seed

recs = [json.loads(l) for l in open(os.path.join(HERE, 'results_v3.jsonl'))]
cache = {}
bad, degenerate, n = [], 0, 0
for x in recs:
    files, dens, kind, T1, T2, sid = SETS[x['set']]
    key = (x['set'], x['k'])
    if key not in cache:
        cache.clear(); cache[key] = np.array(Image.open(files[x['k']]).convert('RGB'))
    I = cache[key]
    di = dens.index(x['density'])
    assert seed(sid, x['k'], di, x['r']) == x['seed']
    Y = corrupt(I, x['density'] / 100, kind, x['seed'])
    M = (Y <= T1) | (Y >= T2)
    assert abs(M.mean() - x['mask']) < 1e-12
    for ch in range(3):
        n += 1
        if M[:, :, ch].all():
            degenerate += 1
            continue
        d = distance_transform_cdt(M[:, :, ch], metric='chessboard')
        pred = int(np.ceil(d.max() / 2))
        if pred != x['sweeps'][ch]:
            bad.append((x['set'], x['k'], x['density'], x['r'], ch, pred, x['sweeps'][ch]))
out = dict(channels=n, mismatches=len(bad), degenerate=degenerate, examples=bad[:10])
json.dump(out, open(os.path.join(HERE, 'verify_sweeps.json'), 'w'), indent=1)
print(out)
