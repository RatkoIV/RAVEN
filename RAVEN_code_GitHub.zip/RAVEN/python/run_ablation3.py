"""Ablation of the revision: TV only (v = 0), no reference term (alpha = 0), channel-wise TGV.
Kodak24 (nS&P) all 24 images and CBSD68 (salt and pepper) every fourth image, densities 10, 50, 90, realization 0."""
import sys, os, json, time, numpy as np
from multiprocessing import Pool
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import core3 as C
from tgvnb import tgv_solve_nb
from solvers3 import pd_solve
from run_v3 import SETS, corrupt, seed, P, q

DEN = [10, 50, 90]

def job(a):
    s, k, d = a
    files, dens, kind, T1, T2, sid = SETS[s]
    di = dens.index(d)
    I = np.array(Image.open(files[k]).convert('RGB'))
    Y = corrupt(I, d / 100, kind, seed(sid, k, di, 0)).astype(np.float64)
    M = (Y <= T1) | (Y >= T2)
    Rf, _ = C.reference(Y, M)
    out = dict(set=s, k=k, density=d)
    out['tv'] = C.metrics(I, q(pd_solve(Y, M, Rf, P['alpha'], P['lam0'], P['lam1'], P['iters'], True, True, P['step'])[0]))
    out['alpha0'] = C.metrics(I, q(tgv_solve_nb(Y, M, Rf, 0.0, P['lam0'], P['lam1'], P['iters'], True, P['step'])))
    out['chan'] = C.metrics(I, q(tgv_solve_nb(Y, M, Rf, P['alpha'], P['lam0'], P['lam1'], P['iters'], False, P['step'])))
    return out

if __name__ == '__main__':
    OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results_ablation3.jsonl')
    tasks = [('kodak24', k, d) for k in range(24) for d in DEN] + [('cbsd68', k, d) for k in range(0, 68, 4) for d in DEN]
    t0 = time.time()
    with Pool(2) as pool, open(OUT, 'w') as f:
        for i, x in enumerate(pool.imap_unordered(job, tasks, chunksize=1)):
            f.write(json.dumps(x) + '\n'); f.flush()
            if i % 20 == 0: print(i, len(tasks), round(time.time() - t0), flush=True)
    print('done', time.time() - t0)
