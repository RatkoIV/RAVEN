"""Python ports of the MATLAB functions used in the evaluation (ssim, rgb2gray, edge('Canny'), imhist),
of the weighted-average Regeneration filter and of lod_dct_class.m, and the earlier per-sample variant."""
import numpy as np
from numba import njit
from scipy import ndimage
from scipy.fft import dct

# ----------------------------------------------------------------- RAVEN
DIRS = np.array([[-1, 0], [0, -1], [0, 1], [1, 0], [-1, -1], [1, 1], [-1, 1], [1, -1]], dtype=np.int64)


@njit(cache=True)
def _median(a):
    b = np.sort(a)
    n = b.size
    if n % 2 == 1:
        return b[n // 2]
    return 0.5 * (b[n // 2 - 1] + b[n // 2])


@njit(cache=True)
def _nb3(Xc, M, i, j, h, w, vals, wts):
    n = 0
    for di in range(-1, 2):
        for dj in range(-1, 2):
            if di == 0 and dj == 0:
                continue
            p = i + di
            q = j + dj
            if p >= 0 and p < h and q >= 0 and q < w and not M[p, q]:
                vals[n] = Xc[p, q]
                wts[n] = np.exp(-(di * di + dj * dj) / 2.0)
                n += 1
    if n >= 3:
        v = vals[:n]
        med = _median(v)
        mad = _median(np.abs(v - med)) + 1e-6
        sig = 1.4826 * mad * 2.5 + 8.0
        for k in range(n):
            wts[k] = wts[k] * np.exp(-((vals[k] - med) ** 2) / (2 * sig * sig))
    return n


@njit(cache=True)
def _nb5(Xc, M, i, j, h, w, vals, wts):
    n = 0
    for di in range(-2, 3):
        for dj in range(-2, 3):
            if di == 0 and dj == 0:
                continue
            p = i + di
            q = j + dj
            if p >= 0 and p < h and q >= 0 and q < w and not M[p, q]:
                vals[n] = Xc[p, q]
                wts[n] = 0.3 * np.exp(-(di * di + dj * dj) / 6.0)
                n += 1
    return n


@njit(cache=True)
def _admm(R, nv, nw, alpha, lam, beta, g, K):
    N = nv.size
    x = R
    z = x - nv
    u = np.zeros(N)
    rho = max(2 * alpha, 0.5)
    for it in range(K):
        s = 0.0
        for k in range(N):
            s += nv[k] + z[k] - u[k]
        x = (2 * alpha * R + 2 * beta * g + rho * s) / (2 * alpha + 2 * beta + rho * N)
        for k in range(N):
            a = (x - nv[k]) + u[k]
            thr = (lam * nw[k]) / rho
            z[k] = np.sign(a) * max(abs(a) - thr, 0.0)
            u[k] = u[k] + (x - nv[k] - z[k])
    return min(max(x, 0.0), 255.0)


@njit(cache=True)
def _raven_channel(Xc, T1, T2, T_outer, K, alpha, lam_base, beta_base, dirs):
    h, w = Xc.shape
    Xc = Xc.copy()
    M = (Xc <= T1) | (Xc >= T2)
    C = np.empty((h, w))
    for i in range(h):
        for j in range(w):
            C[i, j] = 0.0 if M[i, j] else 1.0
    vals = np.zeros(24)
    wts = np.zeros(24)
    sweeps = 0
    for t in range(T_outer):
        for d in range(dirs.shape[0]):
            if not M.any():
                break
            di = dirs[d, 0]
            dj = dirs[d, 1]
            newX = Xc.copy()
            newM = M.copy()
            for ii in range(h):
                i = ii if di >= 0 else h - 1 - ii
                for jj in range(w):
                    j = jj if dj >= 0 else w - 1 - jj
                    if not M[i, j]:
                        continue
                    n = _nb3(Xc, M, i, j, h, w, vals, wts)
                    if n == 0:
                        n = _nb5(Xc, M, i, j, h, w, vals, wts)
                        if n == 0:
                            continue
                    v = vals[:n].copy()
                    ww = wts[:n].copy()
                    R = np.sum(ww * v) / np.sum(ww)
                    g = _median(v)
                    i0 = max(0, i - 1); i1 = min(h - 1, i + 1)
                    j0 = max(0, j - 1); j1 = min(w - 1, j + 1)
                    cs = 0.0
                    for p in range(i0, i1 + 1):
                        for q in range(j0, j1 + 1):
                            cs += C[p, q]
                    theta = 1.0 - cs / ((i1 - i0 + 1) * (j1 - j0 + 1))
                    e = abs(R - g)
                    lam = lam_base * (1 + 1.5 * theta) / (1 + 0.05 * e)
                    beta = beta_base * (1 + 1.5 * theta) / (1 + 0.02 * e)
                    newX[i, j] = _admm(R, v, ww, alpha, lam, beta, g, K)
                    newM[i, j] = False
                    C[i, j] = min(1.0, 0.4 + 0.1 * n)
            Xc = newX
            M = newM
            sweeps += 1
        if not M.any():
            break
    return np.minimum(np.maximum(Xc, 0.0), 255.0), sweeps


def raven_filter(Y, T1=8, T2=247, T_outer=4, K=6, alpha=1.0, lam_base=0.6, beta_base=0.4):
    Y = np.asarray(Y, dtype=np.float64)
    if Y.ndim == 2:
        Y = Y[:, :, None]
    X = np.empty_like(Y)
    sw = []
    for c in range(Y.shape[2]):
        X[:, :, c], s = _raven_channel(np.ascontiguousarray(Y[:, :, c]), T1, T2, T_outer, K, alpha,
                                       lam_base, beta_base, DIRS)
        sw.append(s)
    return X, sw


# ----------------------------------------------------------------- Regeneration
def regeneration_filter(A):
    X = np.asarray(A).astype(np.float64)
    if X.ndim == 2:
        X = X[:, :, None]
    for di, dj in DIRS:
        h, w = X.shape[:2]
        B = X.copy()
        ri = np.arange(max(1, 1 - di), min(h, h - di) + 1) - 1
        rj = np.arange(max(1, 1 - dj), min(w, w - dj) + 1) - 1
        T = X[np.ix_(ri, rj)].copy()
        S = X[np.ix_(ri + di, rj + dj)]
        m = (T > 254) | (T < 2)
        T[m] = S[m]
        B[np.ix_(ri, rj)] = T
        X = B
    return X


# ----------------------------------------------------------------- MATLAB helpers
_RGB2GRAY = np.array([0.298936021293775, 0.587043074451121, 0.114020904255103])


def rgb2gray(img):
    """MATLAB rgb2gray: uint8 input -> rounded uint8, double input -> double."""
    a = np.asarray(img)
    g = a[..., 0].astype(np.float64) * _RGB2GRAY[0] + a[..., 1] * _RGB2GRAY[1] + a[..., 2] * _RGB2GRAY[2]
    if a.dtype == np.uint8:
        return np.clip(np.round(g), 0, 255).astype(np.uint8)
    return g


def ssim_matlab(A, B, L=255.0):
    """MATLAB ssim defaults: Gaussian sigma 1.5, 11x11, replicate padding, K=[0.01 0.03], mean of full map."""
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    f = lambda X: ndimage.gaussian_filter(X, 1.5, mode='nearest', truncate=5 / 1.5)
    C1 = (0.01 * L) ** 2
    C2 = (0.03 * L) ** 2
    mux, muy = f(A), f(B)
    sx = f(A * A) - mux ** 2
    sy = f(B * B) - muy ** 2
    sxy = f(A * B) - mux * muy
    m = ((2 * mux * muy + C1) * (2 * sxy + C2)) / ((mux ** 2 + muy ** 2 + C1) * (sx + sy + C2))
    return float(m.mean())


def ssim_global(a, b):
    """ssim_local from the old RAVEN_Batch.m (one window over the whole image)."""
    a = np.asarray(a, np.float64).ravel(); b = np.asarray(b, np.float64).ravel()
    mua, mub = a.mean(), b.mean()
    va, vb = a.var(ddof=1), b.var(ddof=1)
    cab = np.mean((a - mua) * (b - mub))
    c1 = (0.01 * 255) ** 2; c2 = (0.03 * 255) ** 2
    return float(((2 * mua * mub + c1) * (2 * cab + c2)) / ((mua ** 2 + mub ** 2 + c1) * (va + vb + c2)))


def psnr(I, X):
    e = np.asarray(I, np.float64) - np.asarray(X, np.float64)
    mse = np.mean(e ** 2)
    return float(10 * np.log10(255.0 ** 2 / mse)) if mse > 0 else 100.0


def imhist_double(x, n=256):
    """MATLAB imhist for double input: range [0,1], idx = floor(x*(n-1)+0.5), clipped."""
    idx = np.floor(np.asarray(x, np.float64) * (n - 1) + 0.5)
    idx = np.clip(idx, 0, n - 1).astype(np.int64)
    return np.bincount(idx.ravel(), minlength=n).astype(np.float64)


def _filt1(I, k, axis):
    """imfilter(I, k, 'conv', 'replicate') for a 1-D odd kernel along axis."""
    hr = k[::-1]
    r = (k.size - 1) // 2
    pad = [(0, 0), (0, 0)]
    pad[axis] = (r, r)
    P = np.pad(I, pad, mode='edge')
    out = np.zeros_like(I)
    n = I.shape[axis]
    for t in range(k.size):
        sl = [slice(None), slice(None)]
        sl[axis] = slice(t, t + n)
        out += hr[t] * P[tuple(sl)]
    return out


def edge_canny_matlab(I):
    """MATLAB edge(I,'Canny') with default sigma=sqrt(2) and automatic thresholds."""
    I = np.asarray(I, np.float64)
    sigma = np.sqrt(2)
    ext = int(np.ceil(4 * sigma))
    x = np.arange(-ext, ext + 1, dtype=np.float64)
    g = np.exp(-(x ** 2) / (2 * sigma ** 2)) / (np.sqrt(2 * np.pi) * sigma)
    g = g / g.sum()
    dg = np.gradient(g)
    pos, neg = dg > 0, dg < 0
    dg[pos] = dg[pos] / dg[pos].sum()
    dg[neg] = dg[neg] / abs(dg[neg].sum())
    GX = _filt1(_filt1(I, g, 0), dg, 1)
    GY = _filt1(_filt1(I, g, 1), dg, 0)
    mag = np.hypot(GX, GY)
    mx = mag.max()
    if mx > 0:
        mag = mag / mx
    m, n = mag.shape
    counts = imhist_double(mag, 64)
    hi_idx = np.nonzero(np.cumsum(counts) > 0.7 * m * n)[0][0] + 1
    high = hi_idx / 64.0
    low = 0.4 * high
    ix, iy = GX, GY
    E = np.zeros((m, n), bool)
    strong = np.zeros((m, n), bool)
    inner = np.zeros((m, n), bool)
    inner[1:-1, 1:-1] = True
    P = np.pad(mag, 1, mode='constant')
    sh = lambda di, dj: P[1 + di:1 + di + m, 1 + dj:1 + dj + n]   # mag(i+di, j+dj)
    with np.errstate(divide='ignore', invalid='ignore'):
        conds = [((iy <= 0) & (ix > -iy)) | ((iy >= 0) & (ix < -iy)),
                 ((ix > 0) & (-iy >= ix)) | ((ix < 0) & (-iy <= ix)),
                 ((ix <= 0) & (ix > iy)) | ((ix >= 0) & (ix < iy)),
                 ((iy < 0) & (ix <= iy)) | ((iy > 0) & (ix >= iy))]
        for d in range(4):
            sel = conds[d] & inner
            if d == 0:
                dd = np.abs(iy / ix)
                g1 = sh(0, 1) * (1 - dd) + sh(-1, 1) * dd
                g2 = sh(0, -1) * (1 - dd) + sh(1, -1) * dd
            elif d == 1:
                dd = np.abs(ix / iy)
                g1 = sh(-1, 0) * (1 - dd) + sh(-1, 1) * dd
                g2 = sh(1, 0) * (1 - dd) + sh(1, -1) * dd
            elif d == 2:
                dd = np.abs(ix / iy)
                g1 = sh(-1, 0) * (1 - dd) + sh(-1, -1) * dd
                g2 = sh(1, 0) * (1 - dd) + sh(1, 1) * dd
            else:
                dd = np.abs(iy / ix)
                g1 = sh(0, -1) * (1 - dd) + sh(-1, -1) * dd
                g2 = sh(0, 1) * (1 - dd) + sh(1, 1) * dd
            lm = sel & (mag >= g1) & (mag >= g2)
            weak = lm & (mag > low)
            E |= weak
            strong |= weak & (mag > high)
    if not strong.any():
        return np.zeros((m, n), bool)
    lab, _ = ndimage.label(E, structure=np.ones((3, 3)))
    keep = np.unique(lab[strong])
    keep = keep[keep > 0]
    return np.isin(lab, keep)


def isii(img1, img2):
    """isii.m verbatim (structural term vectorised, imhist on double, numel(intersect) doubling)."""
    C = 1e-6
    a = np.asarray(img1, np.float64)
    b = np.asarray(img2, np.float64)
    if a.ndim == 2:
        a = a[:, :, None]; b = b[:, :, None]
    m, n, _ = a.shape

    def gb(I):
        dx = np.concatenate([np.zeros((1,) + I.shape[1:]), I[:-1] - I[1:]], 0)
        dy = np.concatenate([np.zeros((I.shape[0], 1, I.shape[2])), I[:, :-1] - I[:, 1:]], 1)
        return dx, dy
    dx1, dy1 = gb(a); dx2, dy2 = gb(b)
    num = ((dx1 - dx2) ** 2).sum(2) + ((dy1 - dy2) ** 2).sum(2)
    den = (dx1 ** 2).sum(2) + (dy1 ** 2).sum(2) + (dx2 ** 2).sum(2) + (dy2 ** 2).sum(2) + C
    s = 1 - np.sum(num / den) / (m * n)
    s = np.real(np.power(complex(s), 0.25)) if s < 0 else s ** 0.25
    g1 = rgb2gray(a) if a.shape[2] > 1 else a[:, :, 0]
    g2 = rgb2gray(b) if b.shape[2] > 1 else b[:, :, 0]
    h1 = np.cumsum(imhist_double(g1)); h2 = np.cumsum(imhist_double(g2))
    col = (np.sum(np.minimum(h1, h2)) / np.sum(np.maximum(h1, h2))) ** 4
    e1 = edge_canny_matlab(g1); e2 = edge_canny_matlab(g2)
    common = 2 * np.count_nonzero(e1 & e2)
    total = min(np.count_nonzero(e1), np.count_nonzero(e2)) + C
    tex = ((common / total) * 100 / 100) / 2
    return float((s + col + tex) / 3), float(s), float(col), float(tex)


def lod_class(img, N=8):
    g = rgb2gray(img[:, :, :3]).astype(np.float64) if img.ndim == 3 else np.asarray(img, np.float64)
    h = (g.shape[0] // N) * N; w = (g.shape[1] // N) * N
    g = g[:h, :w]
    B = g.reshape(h // N, N, w // N, N).transpose(0, 2, 1, 3)
    T = dct(dct(B, type=2, norm='ortho', axis=2), type=2, norm='ortho', axis=3)
    E = (T ** 2).sum(axis=(0, 1))
    U, V = np.meshgrid(np.arange(N), np.arange(N), indexing='ij')
    F = np.sqrt(U ** 2 + V ** 2) / (np.sqrt(2) * (N - 1))
    E[0, 0] = 0
    cen = float((F * E).sum() / E.sum()) if E.sum() > 0 else 0.0
    return min(20, int(np.floor(cen / 0.05)) + 1), cen
