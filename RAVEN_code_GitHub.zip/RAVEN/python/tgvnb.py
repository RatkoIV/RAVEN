"""Numba primal-dual solver for the joint TGV model (6), channels coupled (vectorial TGV)."""
import numpy as np
from numba import njit, prange

@njit(cache=True, fastmath=False)
def _pd(Y, A, Rf, X, alpha, lam0, lam1, iters, vec, step):
    h, w, C = Y.shape
    tau = step; sig = step
    v1 = np.zeros((h, w, C)); v2 = np.zeros((h, w, C))
    for c in range(C):
        for i in range(h):
            for j in range(w):
                v1[i, j, c] = X[i, j + 1, c] - X[i, j, c] if j < w - 1 else 0.0
                v2[i, j, c] = X[i + 1, j, c] - X[i, j, c] if i < h - 1 else 0.0
    p1 = np.zeros((h, w, C)); p2 = np.zeros((h, w, C))
    q11 = np.zeros((h, w, C)); q22 = np.zeros((h, w, C)); q12 = np.zeros((h, w, C))
    Xb = X.copy(); v1b = v1.copy(); v2b = v2.copy()
    Xo = np.empty_like(X); v1o = np.empty_like(X); v2o = np.empty_like(X)
    for it in range(iters):
        # dual p
        for i in range(h):
            for j in range(w):
                ss = 0.0
                for c in range(C):
                    gx = (Xb[i, j + 1, c] - Xb[i, j, c]) if j < w - 1 else 0.0
                    gy = (Xb[i + 1, j, c] - Xb[i, j, c]) if i < h - 1 else 0.0
                    p1[i, j, c] += sig * (gx - v1b[i, j, c]); p2[i, j, c] += sig * (gy - v2b[i, j, c])
                    ss += p1[i, j, c] ** 2 + p2[i, j, c] ** 2
                if vec:
                    s = max(1.0, np.sqrt(ss) / lam0)
                    for c in range(C):
                        p1[i, j, c] /= s; p2[i, j, c] /= s
                else:
                    for c in range(C):
                        s = max(1.0, np.sqrt(p1[i, j, c] ** 2 + p2[i, j, c] ** 2) / lam0)
                        p1[i, j, c] /= s; p2[i, j, c] /= s
        # dual q, E(v) with backward differences (bx, by in solvers3.py)
        for i in range(h):
            for j in range(w):
                ss = 0.0
                for c in range(C):
                    if j == 0: bxv1 = v1b[i, 0, c]; bxv2 = v2b[i, 0, c]
                    elif j == w - 1: bxv1 = -v1b[i, w - 2, c]; bxv2 = -v2b[i, w - 2, c]
                    else: bxv1 = v1b[i, j, c] - v1b[i, j - 1, c]; bxv2 = v2b[i, j, c] - v2b[i, j - 1, c]
                    if i == 0: byv1 = v1b[0, j, c]; byv2 = v2b[0, j, c]
                    elif i == h - 1: byv1 = -v1b[h - 2, j, c]; byv2 = -v2b[h - 2, j, c]
                    else: byv1 = v1b[i, j, c] - v1b[i - 1, j, c]; byv2 = v2b[i, j, c] - v2b[i - 1, j, c]
                    q11[i, j, c] += sig * bxv1; q22[i, j, c] += sig * byv2; q12[i, j, c] += sig * 0.5 * (byv1 + bxv2)
                    ss += q11[i, j, c] ** 2 + q22[i, j, c] ** 2 + 2 * q12[i, j, c] ** 2
                if vec:
                    s = max(1.0, np.sqrt(ss) / lam1)
                    for c in range(C):
                        q11[i, j, c] /= s; q22[i, j, c] /= s; q12[i, j, c] /= s
                else:
                    for c in range(C):
                        s = max(1.0, np.sqrt(q11[i, j, c] ** 2 + q22[i, j, c] ** 2 + 2 * q12[i, j, c] ** 2) / lam1)
                        q11[i, j, c] /= s; q22[i, j, c] /= s; q12[i, j, c] /= s
        # primal
        Xo[:] = X; v1o[:] = v1; v2o[:] = v2
        for i in range(h):
            for j in range(w):
                for c in range(C):
                    # div p = bx(p1) + by(p2)
                    if j == 0: d1 = p1[i, 0, c]
                    elif j == w - 1: d1 = -p1[i, w - 2, c]
                    else: d1 = p1[i, j, c] - p1[i, j - 1, c]
                    if i == 0: d2 = p2[0, j, c]
                    elif i == h - 1: d2 = -p2[h - 2, j, c]
                    else: d2 = p2[i, j, c] - p2[i - 1, j, c]
                    if A[i, j, c]:
                        X[i, j, c] = Y[i, j, c]
                    else:
                        xt = X[i, j, c] + tau * (d1 + d2)
                        xt = (xt + tau * alpha * Rf[i, j, c]) / (1 + tau * alpha)
                        X[i, j, c] = min(max(xt, 0.0), 1.0)
                    # div2 q: (fx q11 + fy q12, fx q12 + fy q22)
                    fxq11 = (q11[i, j + 1, c] - q11[i, j, c]) if j < w - 1 else 0.0
                    fyq12 = (q12[i + 1, j, c] - q12[i, j, c]) if i < h - 1 else 0.0
                    fxq12 = (q12[i, j + 1, c] - q12[i, j, c]) if j < w - 1 else 0.0
                    fyq22 = (q22[i + 1, j, c] - q22[i, j, c]) if i < h - 1 else 0.0
                    v1[i, j, c] += tau * (p1[i, j, c] + fxq11 + fyq12)
                    v2[i, j, c] += tau * (p2[i, j, c] + fxq12 + fyq22)
        for i in range(h):
            for j in range(w):
                for c in range(C):
                    Xb[i, j, c] = 2 * X[i, j, c] - Xo[i, j, c]
                    v1b[i, j, c] = 2 * v1[i, j, c] - v1o[i, j, c]
                    v2b[i, j, c] = 2 * v2[i, j, c] - v2o[i, j, c]
    return X

def tgv_solve_nb(Y, M, Rf, alpha=0.0, lam0=1.0, lam1=2.0, iters=200, vectorial=True, step=0.24):
    Y = np.ascontiguousarray(np.asarray(Y, np.float64) / 255.0)
    Rf = np.ascontiguousarray(np.asarray(Rf, np.float64) / 255.0)
    A = np.ascontiguousarray(~M)
    X = Rf.copy(); X[A] = Y[A]
    return _pd(Y, A, Rf, X, alpha, lam0, lam1, iters, vectorial, step) * 255.0
