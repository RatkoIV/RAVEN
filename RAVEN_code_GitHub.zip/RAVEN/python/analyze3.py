"""Aggregate the revision runs: per-image means over realizations, paired statistics with bootstrap CI and Holm
adjustment, level of detail, Figs. 4-6 and Fig. 8, ablation and convergence summaries -> nums3.json."""
import json, sys, os, glob
import numpy as np
from scipy import stats
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.environ.get('FIG', os.path.join(HERE, 'figures'))
os.makedirs(FIG, exist_ok=True)
sys.path.insert(0, HERE)
import ravenlib as R
from run_v3 import SETS

rs = [json.loads(l) for l in open(os.path.join(HERE, 'results_v3.jsonl'))]
NREAL = 3
METHODS = {'kodak24': ['reg', 'rav'], 'cbsd68': ['reg', 'rav', 'mf', 'amf', 'dba']}
IDX = ['psnr', 'ssim', 'isii']
N = {}
arr = {}
for s in SETS:
    files, dens = SETS[s][0], SETS[s][1]
    n, nd = len(files), len(dens)
    full = {(f, m): np.full((n, nd, NREAL), np.nan) for f in METHODS[s] for m in IDX + ['isii_c', 'isii_s', 'isii_t']}
    mask = np.full((n, nd, NREAL), np.nan); fmask = mask.copy(); ttgv = mask.copy(); tref = mask.copy(); sweeps = mask.copy()
    regown = np.full((n, nd), np.nan)
    for r in rs:
        if r['set'] != s:
            continue
        i, j, k = r['k'], dens.index(r['density']), r['r']
        for f in METHODS[s]:
            for m in [mm for (ff, mm) in full if ff == f]:
                full[(f, m)][i, j, k] = r[f][m]
        mask[i, j, k] = r['mask']; fmask[i, j, k] = r['false_mask']; ttgv[i, j, k] = r['t_tgv']; tref[i, j, k] = r['t_ref']
        sweeps[i, j, k] = max(r['sweeps'])
        if 'reg_own' in r:
            regown[i, j] = r['reg_own']['psnr']
    complete = not np.isnan(full[('rav', 'psnr')]).any()
    N[s] = dict(n=n, dens=dens, complete=bool(complete), n_records=int(np.sum(~np.isnan(full[('rav', 'psnr')]))),
                mask=np.nanmean(mask, (0, 2)).tolist(), false_mask=np.nanmean(fmask, (0, 2)).tolist(),
                t_tgv=float(np.nanmean(ttgv)), t_ref=float(np.nanmean(tref)), max_sweeps=np.nanmax(sweeps, (0, 2)).tolist(),
                median_sweeps=np.nanmedian(sweeps, (0, 2)).tolist(), files=[os.path.basename(f) for f in files])
    if not np.isnan(regown).all():
        N[s]['reg_own_psnr_mean'] = np.nanmean(regown, 0).tolist()
    for (f, m), a in full.items():
        per_img = np.nanmean(a, 2)                       # mean over realizations
        arr[(s, f, m)] = per_img
        N[s][f'{f}_{m}_mean'] = np.nanmean(per_img, 0).tolist()
        N[s][f'{f}_{m}_std'] = np.nanstd(per_img, 0, ddof=1).tolist()
        # spread of the dataset mean over realizations
        N[s][f'{f}_{m}_real_sd'] = np.nanstd(np.nanmean(a, 0), 1, ddof=1).tolist() if NREAL > 1 else None
    rng = np.random.default_rng(20261107)
    for m in IDX:
        d = arr[(s, 'rav', m)] - arr[(s, 'reg', m)]
        N[s][f'd_{m}_mean'] = np.nanmean(d, 0).tolist(); N[s][f'd_{m}_std'] = np.nanstd(d, 0, ddof=1).tolist()
        N[s][f'wins_{m}'] = (d > 0).sum(0).tolist()
        lo, hi, pv = [], [], []
        for j in range(nd):
            dj = d[:, j][~np.isnan(d[:, j])]
            bs = rng.choice(dj, size=(10000, dj.size), replace=True).mean(1)
            lo.append(float(np.percentile(bs, 2.5))); hi.append(float(np.percentile(bs, 97.5)))
            pv.append(float(stats.wilcoxon(dj).pvalue))
        N[s][f'ci_{m}'] = [lo, hi]; N[s][f'p_{m}'] = pv
    lod = [R.lod_class(np.array(Image.open(f).convert('RGB'))) for f in files]
    N[s]['lod_class'] = [c for c, _ in lod]; N[s]['lod_centroid'] = [c for _, c in lod]
    cen = np.array(N[s]['lod_centroid'])
    N[s]['spearman_lod_rav_psnr'] = [list(map(float, stats.spearmanr(cen, arr[(s, 'rav', 'psnr')][:, j]))) for j in range(nd)]
    N[s]['spearman_lod_dpsnr'] = [list(map(float, stats.spearmanr(cen, arr[(s, 'rav', 'psnr')][:, j] - arr[(s, 'reg', 'psnr')][:, j]))) for j in range(nd)]
    N[s]['colour_term_min'] = float(np.nanmin([np.nanmin(full[(f, 'isii_c')]) for f in METHODS[s]]))
    N[s]['colour_term_frac_099'] = float(np.nanmean(np.concatenate([full[(f, 'isii_c')].ravel() for f in ('reg', 'rav')]) > 0.99))
# Holm over all paired tests of both studies
tests = [(s, m, j, N[s][f'p_{m}'][j]) for s in N for m in IDX for j in range(len(N[s]['dens']))]
order = np.argsort([t[3] for t in tests]); mtot = len(tests)
adj = np.empty(mtot); run = 0.0
for rank, ti in enumerate(order):
    run = max(run, min(1.0, (mtot - rank) * tests[ti][3])); adj[ti] = run
for (s, m, j, p), a in zip(tests, adj):
    N[s].setdefault(f'pholm_{m}', [None] * len(N[s]['dens']))[j] = float(a)
N['holm'] = dict(m=mtot, max_adj=float(adj.max()), max_raw=float(max(t[3] for t in tests)))

# ------------------------------------------------------------------ ablation
if os.path.exists(os.path.join(HERE, 'results_ablation3.jsonl')):
    ab = [json.loads(l) for l in open(os.path.join(HERE, 'results_ablation3.jsonl'))]
    full_r0 = {(x['set'], x['k'], x['density']): x for x in rs if x['r'] == 0}
    A = {}
    for s, imgs in (('kodak24', list(range(24))), ('cbsd68', list(range(0, 68, 4)))):
        for d in (10, 50, 90):
            rows = [x for x in ab if x['set'] == s and x['density'] == d]
            if len(rows) != len(imgs):
                continue
            for v in ('tv', 'alpha0', 'chan'):
                for m in ('psnr', 'ssim'):
                    A[f'{s}|{v}|{m}|{d}'] = float(np.mean([x[v][m] for x in rows]))
            for v in ('reg', 'rav'):
                for m in ('psnr', 'ssim'):
                    A[f'{s}|{v}|{m}|{d}'] = float(np.mean([full_r0[(s, x['k'], d)][v][m] for x in rows]))
    N['ablation'] = A

# ------------------------------------------------------------------ convergence
EPS = [1e-1, 3e-2, 1e-2, 3e-3, 1e-3, 3e-4, 1e-4]
def t_to(t, gap, e):
    h = np.nonzero(np.asarray(gap) <= e)[0]
    return float(np.asarray(t)[h[0]]) if h.size else float('nan')
if os.path.exists(os.path.join(HERE, 'results_conv3.jsonl')):
    cv = [json.loads(l) for l in open(os.path.join(HERE, 'results_conv3.jsonl'))]
    Cn = dict(cases=len(cv))
    gap200, gap1000, dps, dss, t_pd200, t_admm, adm_gap, dF200, pr200, dr200 = [], [], [], [], [], [], [], [], [], []
    T_pd = {e: [] for e in EPS}; T_ad = {e: [] for e in EPS}
    d_admm_pd, ad_lower, g1000 = [], [], []
    for x in cv:
        fstar = min(min(x['pd']['obj']), min(x['admm']['obj']))
        it = x['pd']['it']; ob = np.array(x['pd']['obj'])
        i200 = it.index(200); i1000 = it.index(1000); i190 = it.index(190)
        gap200.append((ob[i200] - fstar) / fstar); gap1000.append((ob[i1000] - fstar) / fstar)
        dF200.append(abs(ob[i200] - ob[i190]) / ob[i200])
        pr200.append(x['pd']['pres'][i200] / x['pd']['pres'][0]); dr200.append(x['pd']['dres'][i200] / x['pd']['dres'][0])
        dps.append(x['pd']['psnr'][i200] - x['pd']['psnr'][i1000]); dss.append(x['pd']['ssim'][i200] - x['pd']['ssim'][i1000])
        t_pd200.append(x['pd']['t'][i200])
        ta = np.array(x['admm']['t']); oa = np.array(x['admm']['obj'])
        hit = np.nonzero(oa <= ob[i200])[0]
        t_admm.append(float(ta[hit[0]]) if hit.size else float('nan'))
        adm_gap.append((oa[-1] - fstar) / fstar)
        d_admm_pd.append(x['psnr_admm'] - x['pd']['psnr'][i1000])
        g1000.append((x['pd']['psnr'][i1000] - x['psnr_ref'], x['pd']['ssim'][i1000] - x['ssim_ref']))
        ia = list(x['admm']['it']).index(200); ad_lower.append(bool(oa[ia] < ob[i200]))
        for e in EPS:
            T_pd[e].append(t_to(x['pd']['t'], (ob - fstar) / fstar, e)); T_ad[e].append(t_to(ta, (oa - fstar) / fstar, e))
    Cn.update(gap200_median=float(np.median(gap200)), gap200_max=float(np.max(gap200)), gap1000_max=float(np.max(gap1000)),
              dpsnr_absmax=float(np.max(np.abs(dps))), dssim_absmax=float(np.max(np.abs(dss))),
              dpsnr_mean=float(np.mean(dps)), t_pd200_median=float(np.median(t_pd200)),
              t_admm_to_pd200_median=float(np.nanmedian(t_admm)), admm_reached_pd200=int(np.sum(np.isfinite(t_admm))),
              admm_final_gap_max=float(np.max(adm_gap)), dF200_median=float(np.median(dF200)), dF200_max=float(np.max(dF200)),
              pres200_max=float(np.max(pr200)), dres200_max=float(np.max(dr200)),
              dpsnr_admm_pd1000_absmax=float(np.max(np.abs(d_admm_pd))), admm_lower_at_200=int(np.sum(ad_lower)),
              n_pd200_psnr_higher=int(np.sum(np.array(dps) > 0)), dpsnr_max=float(np.max(dps)), dpsnr_min=float(np.min(dps)),
              dpsnr_median_abs=float(np.median(np.abs(dps))),
              min_gain1000_psnr=float(min(a for a, _ in g1000)), min_gain1000_ssim=float(min(b for _, b in g1000)),
              eps=EPS, t_pd_eps_median=[float(np.median(T_pd[e])) if np.all(np.isfinite(T_pd[e])) else None for e in EPS],
              t_admm_eps_median=[float(np.median(T_ad[e])) if np.all(np.isfinite(T_ad[e])) else None for e in EPS],
              pd_reached_eps=[int(np.sum(np.isfinite(T_pd[e]))) for e in EPS],
              admm_reached_eps=[int(np.sum(np.isfinite(T_ad[e]))) for e in EPS])
    N['conv'] = Cn
json.dump(N, open(os.path.join(HERE, 'nums3.json'), 'w'), indent=1)
np.savez(os.path.join(HERE, 'arrays3.npz'), **{f'{a}_{b}_{c}': v for (a, b, c), v in arr.items()})

# ------------------------------------------------------------------ Figures 4-6
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family': 'Liberation Serif', 'font.size': 10})
s = 'kodak24'; dens = SETS[s][1]; cen = np.array(N[s]['lod_centroid']); order = np.argsort(cen)
lab = [f'{d:g}%' for d in dens]
cols = plt.cm.jet(np.linspace(0, 1, len(dens)))
for fig_no, m, ylab in ((4, 'psnr', 'PSNR (dB)'), (5, 'ssim', 'SSIM'), (6, 'isii', 'ISII')):
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.9), gridspec_kw={'width_ratios': [1.25, 1]})
    a = arr[(s, 'rav', m)][order]
    for j in range(len(dens)):
        ax[0].scatter(np.arange(1, len(order) + 1), a[:, j], s=16, color=cols[j], edgecolor='0.25', linewidth=0.3, label=lab[j], zorder=3)
    ax[0].set_xticks(np.arange(1, len(order) + 1))
    ax[0].set_xticklabels([f'D{N[s]["lod_class"][i]}' for i in order], rotation=90, fontsize=7)
    ax[0].set_xlabel('Kodak24 images ordered by DCT spectral centroid (level-of-detail class)')
    ax[0].set_ylabel(ylab); ax[0].grid(alpha=0.3); ax[0].set_title(f'(a) {m.upper()} of RAVEN per image', fontsize=10)
    ax[0].legend(ncol=1, fontsize=7, loc='center left', bbox_to_anchor=(1.0, 0.5), frameon=False, title='p', title_fontsize=7)
    x = np.arange(len(dens)); w = 0.38
    ax[1].bar(x - w / 2, N[s][f'reg_{m}_std'], w, color='#8C99A8', label='Regeneration')
    ax[1].bar(x + w / 2, N[s][f'rav_{m}_std'], w, color='#2E6B3A', label='RAVEN')
    ax[1].set_xticks(x); ax[1].set_xticklabels(lab, rotation=90, fontsize=8)
    ax[1].set_xlabel('Spatial noise density'); ax[1].set_ylabel(f'StD of {m.upper()}')
    ax[1].set_title('(b) Standard deviation across the 24 images', fontsize=10); ax[1].grid(axis='y', alpha=0.3); ax[1].legend(fontsize=8, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, f'fig{fig_no}.png'), dpi=200); plt.close(fig)

# ------------------------------------------------------------------ Figure 8
if 'conv' in N:
    fig, ax = plt.subplots(2, 3, figsize=(11, 6.6))
    ax = ax.ravel()
    cmap = {10: '#1f77b4', 50: '#2ca02c', 90: '#d62728'}
    for x in cv:
        fstar = min(min(x['pd']['obj']), min(x['admm']['obj']))
        it = np.array(x['pd']['it']); ob = np.array(x['pd']['obj'])
        col = cmap[int(x['density'])]
        pr = np.array(x['pd']['pres']); dr = np.array(x['pd']['dres'])
        ax[0].semilogy(it, pr / pr[0], color=col, lw=0.7, alpha=0.8)
        ax[0].semilogy(it, dr / dr[0], color=col, lw=0.7, alpha=0.8, ls='--')
        ax[1].semilogy(it[1:], np.maximum(np.abs(np.diff(ob)) / ob[1:], 1e-12), color=col, lw=0.7, alpha=0.8)
        ax[2].semilogy(it, np.maximum((ob - fstar) / fstar, 1e-8), color=col, lw=0.7, alpha=0.8)
        ps_ = np.array(x['pd']['psnr']); ax[3].plot(it, ps_ - ps_[-1], color=col, lw=0.7, alpha=0.8)
        ss_ = np.array(x['pd']['ssim']); ax[4].plot(it, ss_ - ss_[-1], color=col, lw=0.7, alpha=0.8)
    for d, col in cmap.items():
        ax[2].plot([], [], color=col, label=f'p = {d}%')
    ax[0].plot([], [], color='k', label='primal'); ax[0].plot([], [], color='k', ls='--', label='dual')
    for j in range(5):
        ax[j].axvline(200, color='0.4', ls=':', lw=0.9); ax[j].set_xlabel('Iteration k'); ax[j].grid(alpha=0.3)
    ax[0].set_title('(a) Residuals relative to k = 1', fontsize=10); ax[0].legend(fontsize=8, frameon=False)
    ax[1].set_title('(b) |F$^k$ − F$^{k−10}$| / F$^k$', fontsize=10)
    ax[2].set_title('(c) (F$^k$ − F*) / F*', fontsize=10); ax[2].legend(fontsize=8, frameon=False)
    ax[3].set_title('(d) PSNR(X$^k$) − PSNR(X$^{1000}$) (dB)', fontsize=10); ax[3].set_ylim(-1.0, 0.8)
    ax[4].set_title('(e) SSIM(X$^k$) − SSIM(X$^{1000}$)', fontsize=10); ax[4].set_ylim(-0.02, 0.006)
    C_ = N['conv']; e_ = np.array(C_['eps'])
    tp = np.array([np.nan if v is None else v for v in C_['t_pd_eps_median']]); ta_ = np.array([np.nan if v is None else v for v in C_['t_admm_eps_median']])
    ax[5].loglog(e_, tp, 'o-', color='k', ms=4, lw=1, label='primal–dual (7)')
    ax[5].loglog(e_, ta_, 's--', color='0.45', ms=4, lw=1, label='ADMM')
    ax[5].invert_xaxis(); ax[5].set_xlabel('Tolerance ε on (F − F*) / F*'); ax[5].set_ylabel('Median time (s)')
    from matplotlib.ticker import FixedLocator, NullLocator, FormatStrFormatter
    ax[5].yaxis.set_major_locator(FixedLocator([1, 2, 5, 10, 20, 50, 100])); ax[5].yaxis.set_minor_locator(NullLocator())
    ax[5].yaxis.set_major_formatter(FormatStrFormatter('%g'))
    ax[5].set_title('(f) Time to reach the tolerance', fontsize=10); ax[5].grid(alpha=0.3, which='both'); ax[5].legend(fontsize=8, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig8.png'), dpi=200); plt.close(fig)
print('ok', {s: (N[s]['n_records'], N[s]['complete']) for s in SETS})
