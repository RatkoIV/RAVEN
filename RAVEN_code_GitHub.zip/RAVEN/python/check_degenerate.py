"""Remark 1 in numbers: iteration (7) with lambda0 or lambda1 close to zero returns the Regeneration reference.
Three Kodak24 images at 10, 50 and 90 percent nS&P, first realization. Writes degenerate_check.json."""
import os, sys, json
import numpy as np
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import core3 as C
from tgvnb import tgv_solve_nb
from run_v3 import corrupt, SETS, seed

files, dens, kind, T1, T2, sid = SETS['kodak24']
mx = 0.0
for k in (0, 11, 22):
    I = np.array(Image.open(files[k]).convert('RGB'))
    for d in (10, 50, 90):
        Y = corrupt(I, d / 100, kind, seed(sid, k, dens.index(d), 0)).astype(float)
        M = (Y <= T1) | (Y >= T2)
        Rf, _ = C.reference(Y, M)
        for l0, l1 in ((1e-12, 0.5), (1.0, 1e-12)):
            X = tgv_solve_nb(Y, M, Rf, 0.1, l0, l1, 200, True, 0.24)
            mx = max(mx, float(np.abs(X - Rf).max()))
print(mx)
json.dump({'degenerate_maxdiff_grey_levels': mx, 'images': [0, 11, 22], 'densities': [10, 50, 90], 'lam_small': 1e-12},
          open(os.path.join(HERE, 'degenerate_check.json'), 'w'))
