"""Mask, Regeneration reference by synchronous sweeps until the mask is empty, ISII as published, median and adaptive median filters."""
import numpy as np
from numba import njit
from scipy import ndimage
import ravenlib as R
from ablation import _nb3_plain


@njit(cache=True)
def _sweeps(Xc, M0):
    """Synchronous sweeps (Eqs. 3-4) until every masked sample has a value (Proposition 1).
    Returns the reference and the number of sweeps. If the channel has no reliable sample,
    the masked samples are set to the mid-grey value."""
    h, w = Xc.shape
    Xc = Xc.copy(); M = M0.copy()
    vals = np.zeros(24); wts = np.zeros(24)
    nsw = 0
    while M.any():
        newX = Xc.copy(); newM = M.copy(); changed = 0
        for i in range(h):
            for j in range(w):
                if not M[i, j]:
                    continue
                n = _nb3_plain(Xc, M, i, j, h, w, vals, wts)
                if n == 0:
                    n = R._nb5(Xc, M, i, j, h, w, vals, wts)
                    if n == 0:
                        continue
                s = 0.0; sw = 0.0
                for k in range(n):
                    s += wts[k] * vals[k]; sw += wts[k]
                newX[i, j] = s / sw; newM[i, j] = False; changed += 1
        Xc = newX; M = newM; nsw += 1
        if changed == 0:          # no reliable sample in the channel
            for i in range(h):
                for j in range(w):
                    if M[i, j]:
                        Xc[i, j] = 127.5
            break
    return Xc, nsw


def reference(Y, M):
    Y = np.asarray(Y, np.float64)
    out = np.empty_like(Y); sw = []
    for c in range(Y.shape[2]):
        out[:, :, c], s = _sweeps(np.ascontiguousarray(Y[:, :, c]), np.ascontiguousarray(M[:, :, c]))
        sw.append(int(s))
    return out, sw


def isii_public(img1, img2):
    """isii.m from github.com/RatkoIV/ISII (commit 50aad7b): C1 = 1e-4 in the structural term,
    imhist on the double grey image, texture from numel(intersect(...,'rows')) halved."""
    C1 = 1e-4
    a = np.asarray(img1, np.float64); b = np.asarray(img2, np.float64)
    if a.ndim == 2:
        a = a[:, :, None]; b = b[:, :, None]
    m, n, _ = a.shape

    def gb(I):
        dx = np.concatenate([np.zeros((1,) + I.shape[1:]), I[:-1] - I[1:]], 0)
        dy = np.concatenate([np.zeros((I.shape[0], 1, I.shape[2])), I[:, :-1] - I[:, 1:]], 1)
        return dx, dy
    dx1, dy1 = gb(a); dx2, dy2 = gb(b)
    num = ((dx1 - dx2) ** 2).sum(2) + ((dy1 - dy2) ** 2).sum(2)
    den = (dx1 ** 2).sum(2) + (dy1 ** 2).sum(2) + (dx2 ** 2).sum(2) + (dy2 ** 2).sum(2) + C1
    s = 1 - np.sum(num / den) / (m * n)
    s = float(np.real(np.power(complex(s), 0.25)))
    g1 = R.rgb2gray(a) if a.shape[2] > 1 else a[:, :, 0]
    g2 = R.rgb2gray(b) if b.shape[2] > 1 else b[:, :, 0]
    h1 = np.cumsum(R.imhist_double(g1)); h2 = np.cumsum(R.imhist_double(g2))
    col = float((np.sum(np.minimum(h1, h2)) / np.sum(np.maximum(h1, h2))) ** 4)
    e1 = R.edge_canny_matlab(g1); e2 = R.edge_canny_matlab(g2)
    k = np.count_nonzero(e1 & e2)
    total = min(np.count_nonzero(e1), np.count_nonzero(e2))
    tex = float('nan') if total == 0 else ((2 * k / total) * 100 / 100) / 2
    return float((s + col + tex) / 3), s, col, tex


def metrics(I, Z):
    v = isii_public(I, Z)
    return dict(psnr=R.psnr(I, Z), ssim=float(np.mean([R.ssim_matlab(Z[:, :, c], I[:, :, c]) for c in range(3)])),
                isii=v[0], isii_s=v[1], isii_c=v[2], isii_t=v[3])


# ------------------------------------------------------------------ controlled baselines
def median3(Y):
    """3 x 3 median filter applied to every sample, replicate padding."""
    return np.stack([ndimage.median_filter(Y[:, :, c], size=3, mode='nearest') for c in range(Y.shape[2])], 2)


@njit(cache=True)
def _amf(X, smax):
    h, w = X.shape
    out = X.copy()
    for i in range(h):
        for j in range(w):
            z = X[i, j]
            s = 1
            while True:
                i0 = max(0, i - s); i1 = min(h - 1, i + s); j0 = max(0, j - s); j1 = min(w - 1, j + s)
                win = X[i0:i1 + 1, j0:j1 + 1].ravel()
                zmin = win.min(); zmax = win.max(); zmed = np.median(win)
                if zmin < zmed < zmax:                 # level A
                    out[i, j] = z if zmin < z < zmax else zmed   # level B
                    break
                s += 1
                if 2 * s + 1 > smax:
                    out[i, j] = zmed
                    break
    return out


def amf(Y, smax=39):
    """Adaptive median filter (Hwang and Haddad), levels A and B as in Gonzalez and Woods, S_max = 39."""
    Y = np.asarray(Y, np.float64)
    return np.stack([_amf(np.ascontiguousarray(Y[:, :, c]), smax) for c in range(Y.shape[2])], 2)
