"""Fig. 7: visual comparison on a Kodak24 image at 70 and 90 percent nS&P (same realisation as the study)."""
import sys, json, glob, numpy as np
import os
HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.environ.get('FIG', os.path.join(HERE, 'figures'))
os.makedirs(FIG, exist_ok=True)
sys.path.insert(0, HERE)
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import ravenlib as R
import core3 as C3
from tgvnb import tgv_solve_nb
from run_v3 import corrupt, P, SETS

files = SETS['kodak24'][0]
D13 = [1, 2, 3, 4, 5, 7.5, 10, 30, 40, 50, 70, 80, 90]
k = int(sys.argv[1]) if len(sys.argv) > 1 else 22
I = np.array(Image.open(files[k]).convert('RGB'))
y0, x0, S = [int(v) for v in (sys.argv[2:5] if len(sys.argv) > 4 else (150, 150, 200))]
plt.rcParams.update({'font.family': 'Liberation Serif', 'font.size': 10})
fig, ax = plt.subplots(2, 4, figsize=(10.4, 6.3))
q = lambda Z: np.floor(np.clip(Z, 0, 255) + 0.5).astype(np.uint8)
info = {}
for row, d in enumerate((70, 90)):
    di = D13.index(d)
    Y = corrupt(I, d / 100, 'nsp', 200000 + 1000 * (k + 1) + di).astype(np.float64)
    M = (Y <= 8) | (Y >= 247)
    Rf, _ = C3.reference(Y, M)
    X = tgv_solve_nb(Y, M, Rf, P['alpha'], P['lam0'], P['lam1'], P['iters'], True, P['step'])
    panels = [('Clean', I), (f'nS&P, p = {d}%', Y), ('Regeneration', q(Rf)), ('RAVEN', q(X))]
    for c, (t, Z) in enumerate(panels):
        Zu = q(Z)
        a = ax[row, c]
        a.imshow(Zu[y0:y0 + S, x0:x0 + S]); a.set_xticks([]); a.set_yticks([])
        if c >= 1:
            ps = R.psnr(I, Zu); ss = np.mean([R.ssim_matlab(Zu[:, :, ch], I[:, :, ch]) for ch in range(3)])
            info[f'{t} ({d}%)'] = (float(ps), float(ss))
            a.set_title(f'{t}\nPSNR {ps:.2f} dB, SSIM {ss:.4f}', fontsize=9)
        else:
            a.set_title(t, fontsize=9)
fig.tight_layout(h_pad=2.2)
fig.savefig(os.path.join(FIG, 'fig7.png'), dpi=200)
json.dump({k2: list(v) for k2, v in info.items()} | {'file': files[k].split('/')[-1], 'crop': [y0, x0, S]},
          open(os.path.join(HERE, 'fig7.json'), 'w'), indent=1)
print(info)
