function [ISII, parts] = isii_index(img1, img2, histUint8)
%ISII_INDEX  Integral C-T-S image similarity index (ISII) as a function.
%
%   ISII = isii_index(img1, img2)
%   [ISII, parts] = isii_index(img1, img2, histUint8)
%
%   The computation follows isii.m from github.com/RatkoIV/ISII (commit 50aad7b):
%     structural term  (backward differences, exponent 0.25),
%     histogram term   (cumulative grey-level histograms, exponent 4),
%     texture term     (overlap of Canny edges).
%   The double loop of the structural term is replaced by an equivalent array
%   expression.
%
%   Texture term: common_pixels = numel(intersect(..., 'rows')) counts the 2k entries
%   of the k common edge positions, and the division by 2 restores the overlap ratio
%   k / min(n1, n2). The term lies in [0, 1] and ISII(I, I) = 1.
%
%   Histogram term: as in isii.m, imhist is applied to the double grey image
%   (histUint8 = false, default). histUint8 = true evaluates the histogram on the
%   256 grey levels of the uint8 image instead.
%
%   Author: Ratko M. Ivkovic, State University of Novi Pazar

    if nargin < 3, histUint8 = false; end

    C1 = 1e-4;                      % as in isii.m, github.com/RatkoIV/ISII, commit 50aad7b
    structural_scale_factor = 0.25;
    color_scale_factor = 4;

    [m1, n1, c1] = size(img1);
    [m2, n2, c2] = size(img2);
    if c1 ~= c2 || m1 ~= m2 || n1 ~= n2
        error('Input images must have the same size.');
    end

    img1 = double(img1);
    img2 = double(img2);

    %% Structural term (array form of the loop in isii.m)
    [dx1, dy1] = grad_back(img1);
    [dx2, dy2] = grad_back(img2);
    num = sum((dx1 - dx2).^2, 3) + sum((dy1 - dy2).^2, 3);
    den = sum(dx1.^2, 3) + sum(dy1.^2, 3) + sum(dx2.^2, 3) + sum(dy2.^2, 3) + C1;
    structural_similarity = 1 - sum(num(:) ./ den(:)) / (m1 * n1);
    structural_similarity = real(structural_similarity ^ structural_scale_factor);

    %% Histogram term
    if size(img1, 3) > 1, gray_img1 = rgb2gray(img1); else, gray_img1 = img1; end
    if size(img2, 3) > 1, gray_img2 = rgb2gray(img2); else, gray_img2 = img2; end

    if histUint8
        hist1 = imhist(uint8(round(gray_img1)));
        hist2 = imhist(uint8(round(gray_img2)));
    else
        hist1 = imhist(gray_img1);     % as in isii.m
        hist2 = imhist(gray_img2);
    end
    int_hist1 = cumsum(hist1);
    int_hist2 = cumsum(hist2);
    color_similarity = sum(min(int_hist1, int_hist2)) / sum(max(int_hist1, int_hist2));
    color_similarity = color_similarity ^ color_scale_factor;

    %% Texture term
    edge_img1 = edge(gray_img1, 'Canny');
    edge_img2 = edge(gray_img2, 'Canny');
    [edge1_rows, edge1_cols] = find(edge_img1);
    [edge2_rows, edge2_cols] = find(edge_img2);
    common_pixels = numel(intersect([edge1_rows, edge1_cols], [edge2_rows, edge2_cols], 'rows'));
    total_pixels  = min(numel(edge1_rows), numel(edge2_rows));
    texture_similarity = (common_pixels / total_pixels) * 100;
    texture_similarity = (texture_similarity / 100) / 2;

    %% Integral index
    ISII = (structural_similarity + color_similarity + texture_similarity) / 3;
    parts = struct('structural', structural_similarity, 'color', color_similarity, ...
                   'texture', texture_similarity);
end

function [dx, dy] = grad_back(I)
% dx(x,y) = I(max(x-1,1),y) - I(x,y),  dy(x,y) = I(x,max(y-1,1)) - I(x,y)
    [m, n, c] = size(I);
    dx = cat(1, zeros(1, n, c), I(1:end-1, :, :) - I(2:end, :, :));
    dy = cat(2, zeros(m, 1, c), I(:, 1:end-1, :) - I(:, 2:end, :));
end
