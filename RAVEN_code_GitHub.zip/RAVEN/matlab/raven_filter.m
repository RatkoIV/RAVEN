function [X, R, M] = raven_filter(Y, opt)
%RAVEN_FILTER  RAVEN = Regeneration filter + joint TGV reconstruction.
%
%   X = raven_filter(Y)              Y: gray or RGB image, uint8 or double in [0,255]
%   [X, R, M] = raven_filter(Y, opt) also returns the Regeneration reference R and the mask M
%
%   Steps (manuscript, Sections 2 and 3):
%     1. Mask M = {Y <= T1} U {Y >= T2}                                  Eq. (2)
%     2. Regeneration reference R by synchronous sweeps, normalized
%        Gaussian-weighted average of valid 3x3 neighbours, 5x5 fallback, Eqs. (3)-(4),
%        repeated until every masked sample has a value (Proposition 1)
%     3. Joint TGV reconstruction                                        Eq. (6)
%          min (alpha/2) sum_M (X-R)^2 + lam0 ||grad X - v||_{2,1} + lam1 ||E(v)||_{2,1}
%          s.t. X = Y on the reliable samples, 0 <= X <= 255,
%        solved by the primal-dual iteration (7) with tau = sigma = 0.24 (tau*sigma < 1/16).
%   Channels are coupled in the TGV norms (vectorial TGV). Intensities are scaled to [0,1]
%   inside the solver.
%
%   Default parameters (chosen on the McMaster set):
%     T1 = 8, T2 = 247, alpha = 0.1, lam0 = 1, lam1 = 0.5, iters = 200
%   For classical salt-and-pepper noise use T1 = 1, T2 = 255 (detection < 2 or > 254).
%
%   Author: Ratko M. Ivkovic, State University of Novi Pazar

    if nargin < 2, opt = struct(); end
    if ~isfield(opt,'T1'),     opt.T1 = 8;      end
    if ~isfield(opt,'T2'),     opt.T2 = 247;    end
    if ~isfield(opt,'alpha'),  opt.alpha = 0.1; end
    if ~isfield(opt,'lam0'),   opt.lam0 = 1.0;  end
    if ~isfield(opt,'lam1'),   opt.lam1 = 0.5;  end
    if ~isfield(opt,'iters'),  opt.iters = 200; end
    if ~isfield(opt,'step'),   opt.step = 0.24; end

    Y = double(Y);
    M = (Y <= opt.T1) | (Y >= opt.T2);
    R = Y;
    for c = 1:size(Y,3)
        R(:,:,c) = regeneration_reference(Y(:,:,c), M(:,:,c));
    end
    X = tgv_reconstruct(Y/255, M, R/255, opt) * 255;
end

%% ------------------------------------------------------------------------
function Xc = regeneration_reference(Xc, M0)
% Synchronous sweeps until the working mask is empty (Proposition 1): every masked
% sample with a nonempty valid neighbourhood receives the normalized Gaussian-weighted
% average of its valid neighbours, and all values are committed at the end of the sweep.
    [h, w] = size(Xc); M = M0;
    [dj3, di3] = meshgrid(-1:1, -1:1); w3 = exp(-(di3.^2 + dj3.^2)/2);
    [dj5, di5] = meshgrid(-2:2, -2:2); w5 = exp(-(di5.^2 + dj5.^2)/6);
    while any(M(:))
        newX = Xc; newM = M; changed = 0;
        [I, J] = find(M);
        for t = 1:numel(I)
            i = I(t); j = J(t);
            [val, wt] = valid(Xc, M, i, j, h, w, 1, w3);
            if isempty(val)
                [val, wt] = valid(Xc, M, i, j, h, w, 2, w5);
                if isempty(val), continue; end
            end
            newX(i,j) = sum(wt .* val) / sum(wt);
            newM(i,j) = false; changed = changed + 1;
        end
        Xc = newX; M = newM;
        if changed == 0          % channel without reliable samples
            Xc(M) = 127.5; break;
        end
    end
end

function [val, wt] = valid(Xc, M, i, j, h, w, r, W)
    i0 = max(1, i-r); i1 = min(h, i+r); j0 = max(1, j-r); j1 = min(w, j+r);
    blkM = M(i0:i1, j0:j1); blkX = Xc(i0:i1, j0:j1);
    blkW = W((i0:i1) - i + r + 1, (j0:j1) - j + r + 1);
    ok = ~blkM; ok(i - i0 + 1, j - j0 + 1) = false;
    val = blkX(ok); wt = blkW(ok);
end

%% ------------------------------------------------------------------------
function X = tgv_reconstruct(Y, M, R, opt)
    A = ~M; tau = opt.step; sig = opt.step;
    X = R; X(A) = Y(A);
    v1 = fx(X); v2 = fy(X);
    p1 = zeros(size(X)); p2 = p1; q11 = p1; q22 = p1; q12 = p1;
    Xb = X; v1b = v1; v2b = v2;
    for k = 1:opt.iters
        p1 = p1 + sig*(fx(Xb) - v1b);  p2 = p2 + sig*(fy(Xb) - v2b);
        s = max(1, sqrt(sum(p1.^2 + p2.^2, 3)) / opt.lam0);
        p1 = p1 ./ s;  p2 = p2 ./ s;
        q11 = q11 + sig*bx(v1b);  q22 = q22 + sig*by(v2b);
        q12 = q12 + sig*0.5*(by(v1b) + bx(v2b));
        s = max(1, sqrt(sum(q11.^2 + q22.^2 + 2*q12.^2, 3)) / opt.lam1);
        q11 = q11 ./ s;  q22 = q22 ./ s;  q12 = q12 ./ s;
        Xo = X; v1o = v1; v2o = v2;
        Xt = X + tau*(bx(p1) + by(p2));
        Xt = min(max((Xt + tau*opt.alpha*R) / (1 + tau*opt.alpha), 0), 1);
        X = Xt; X(A) = Y(A);
        v1 = v1 + tau*(p1 + fx(q11) + fy(q12));
        v2 = v2 + tau*(p2 + fx(q12) + fy(q22));
        Xb = 2*X - Xo;  v1b = 2*v1 - v1o;  v2b = 2*v2 - v2o;
    end
end

function d = fx(u)
    d = zeros(size(u)); d(:,1:end-1,:) = u(:,2:end,:) - u(:,1:end-1,:);
end

function d = fy(u)
    d = zeros(size(u)); d(1:end-1,:,:) = u(2:end,:,:) - u(1:end-1,:,:);
end

function d = bx(p)
    d = zeros(size(p)); d(:,1,:) = p(:,1,:);
    d(:,2:end-1,:) = p(:,2:end-1,:) - p(:,1:end-2,:); d(:,end,:) = -p(:,end-1,:);
end
function d = by(p)
    d = zeros(size(p)); d(1,:,:) = p(1,:,:);
    d(2:end-1,:,:) = p(2:end-1,:,:) - p(1:end-2,:,:); d(end,:,:) = -p(end-1,:,:);
end
