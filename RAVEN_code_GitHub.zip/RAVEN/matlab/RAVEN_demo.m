%% RAVEN_demo.m  Restore one image corrupted by near salt-and-pepper noise (Eq. 1)
%  Requires the Image Processing Toolbox (ssim) and raven_filter.m, isii_index.m on the path.
I = imread('peppers.png');                 % any RGB test image
p = 0.5;                                   % spatial noise density
rng(1);
b = rand(size(I)); Y = I;
lo = b < p/2; hi = b >= p/2 & b < p;
Y(lo) = randi([0 8],   nnz(lo), 1);        % near-black band [0, T1]
Y(hi) = randi([247 255], nnz(hi), 1);      % near-white band [T2, L]

[X, R] = raven_filter(Y);                  % RAVEN and its Regeneration reference
X = uint8(round(X)); R = uint8(round(R));

e = @(Z) 10*log10(255^2 / mean((double(I(:)) - double(Z(:))).^2));
s = @(Z) mean([ssim(Z(:,:,1),I(:,:,1)) ssim(Z(:,:,2),I(:,:,2)) ssim(Z(:,:,3),I(:,:,3))]);
fprintf('Regeneration: PSNR %.2f dB, SSIM %.4f, ISII %.4f\n', e(R), s(R), isii_index(I, R));
fprintf('RAVEN:        PSNR %.2f dB, SSIM %.4f, ISII %.4f\n', e(X), s(X), isii_index(I, X));
montage({I, Y, R, X}, 'Size', [1 4]);
title('clean | nS&P | Regeneration | RAVEN');
