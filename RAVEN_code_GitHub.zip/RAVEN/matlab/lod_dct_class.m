function [cls, centroid, E] = lod_dct_class(img, N)
%LOD_DCT_CLASS  Level-of-detail class D1..D20 from the DCT spectrum, Eq. (11) of the paper.
%
%   [cls, centroid, E] = lod_dct_class(img)       8 x 8 blocks
%   [cls, centroid, E] = lod_dct_class(img, N)    N x N blocks
%
%   The DCT is computed on non-overlapping N x N blocks of the luminance, the energy
%   of every frequency position (u,v) is summed over all blocks, and the centroid is
%   the mean of f_norm = sqrt(u^2+v^2) / (sqrt(2)(N-1)) weighted by that energy,
%   without the DC component. The class is D_k for a centroid in [(k-1)0.05, k*0.05).
%
%   Author: Ratko M. Ivkovic, State University of Novi Pazar

    if nargin < 2, N = 8; end
    if size(img, 3) >= 3, g = rgb2gray(img(:,:,1:3)); else, g = img(:,:,1); end
    g = double(g);
    h = floor(size(g,1)/N)*N;  w = floor(size(g,2)/N)*N;
    g = g(1:h, 1:w);
    nb = (h/N) * (w/N);

    D = dctmtx(N);
    G = reshape(permute(reshape(g, N, h/N, N, w/N), [1 3 2 4]), N, N, nb);   % blokovi
    T = reshape(D * reshape(G, N, []), N, N, nb);                            % D*B
    T = permute(T, [2 1 3]);
    T = reshape(D * reshape(T, N, []), N, N, nb);
    T = permute(T, [2 1 3]);                                                 % D*B*D'
    E = sum(T.^2, 3);

    [U, V] = ndgrid(0:N-1, 0:N-1);
    F = sqrt(U.^2 + V.^2) / (sqrt(2) * (N - 1));
    E(1,1) = 0;                                   % bez DC komponente
    if sum(E(:)) > 0
        centroid = sum(F(:) .* E(:)) / sum(E(:));
    else
        centroid = 0;
    end
    cls = min(20, floor(centroid / 0.05) + 1);
end
